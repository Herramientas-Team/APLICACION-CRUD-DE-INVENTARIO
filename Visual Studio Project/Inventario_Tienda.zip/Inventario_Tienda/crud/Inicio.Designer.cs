﻿namespace Presentacion
{
    partial class Inicio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panelMenuLateral = new Panel();
            button6 = new Button();
            button5 = new Button();
            panelSubMenuCajero = new Panel();
            btnCrearFacturas = new Button();
            btnMenuCajero = new Button();
            panelSubMenuAdministrador = new Panel();
            btnProductos = new Button();
            btnCajeros = new Button();
            btnHistorialFacturas = new Button();
            btnMenuAdministrador = new Button();
            panelLogo = new Panel();
            panelChildForm = new Panel();
            pictureBox1 = new PictureBox();
            panelMenuLateral.SuspendLayout();
            panelSubMenuCajero.SuspendLayout();
            panelSubMenuAdministrador.SuspendLayout();
            panelChildForm.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panelMenuLateral
            // 
            panelMenuLateral.AutoScroll = true;
            panelMenuLateral.BackColor = Color.FromArgb(25, 26, 24);
            panelMenuLateral.Controls.Add(button6);
            panelMenuLateral.Controls.Add(button5);
            panelMenuLateral.Controls.Add(panelSubMenuCajero);
            panelMenuLateral.Controls.Add(btnMenuCajero);
            panelMenuLateral.Controls.Add(panelSubMenuAdministrador);
            panelMenuLateral.Controls.Add(btnMenuAdministrador);
            panelMenuLateral.Controls.Add(panelLogo);
            panelMenuLateral.Dock = DockStyle.Left;
            panelMenuLateral.Location = new Point(0, 0);
            panelMenuLateral.Name = "panelMenuLateral";
            panelMenuLateral.Size = new Size(250, 561);
            panelMenuLateral.TabIndex = 0;
            // 
            // button6
            // 
            button6.BackColor = Color.FromArgb(57, 213, 207);
            button6.Dock = DockStyle.Bottom;
            button6.FlatAppearance.BorderSize = 0;
            button6.FlatStyle = FlatStyle.Flat;
            button6.Location = new Point(0, 481);
            button6.Name = "button6";
            button6.Size = new Size(250, 40);
            button6.TabIndex = 6;
            button6.Text = "Iniciar Sesión";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // button5
            // 
            button5.BackColor = Color.FromArgb(57, 213, 207);
            button5.Dock = DockStyle.Bottom;
            button5.FlatAppearance.BorderSize = 0;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Location = new Point(0, 521);
            button5.Name = "button5";
            button5.Size = new Size(250, 40);
            button5.TabIndex = 5;
            button5.Text = "Cerrar Sesión";
            button5.UseVisualStyleBackColor = false;
            // 
            // panelSubMenuCajero
            // 
            panelSubMenuCajero.BackColor = Color.FromArgb(35, 36, 34);
            panelSubMenuCajero.Controls.Add(btnCrearFacturas);
            panelSubMenuCajero.Dock = DockStyle.Top;
            panelSubMenuCajero.Location = new Point(0, 407);
            panelSubMenuCajero.Name = "panelSubMenuCajero";
            panelSubMenuCajero.Size = new Size(250, 46);
            panelSubMenuCajero.TabIndex = 4;
            // 
            // btnCrearFacturas
            // 
            btnCrearFacturas.Dock = DockStyle.Top;
            btnCrearFacturas.FlatAppearance.BorderSize = 0;
            btnCrearFacturas.FlatAppearance.MouseDownBackColor = Color.FromArgb(11, 114, 110);
            btnCrearFacturas.FlatAppearance.MouseOverBackColor = Color.FromArgb(11, 114, 110);
            btnCrearFacturas.FlatStyle = FlatStyle.Flat;
            btnCrearFacturas.ForeColor = SystemColors.Window;
            btnCrearFacturas.Location = new Point(0, 0);
            btnCrearFacturas.Name = "btnCrearFacturas";
            btnCrearFacturas.Padding = new Padding(35, 0, 0, 0);
            btnCrearFacturas.Size = new Size(250, 40);
            btnCrearFacturas.TabIndex = 2;
            btnCrearFacturas.Text = "Crear Facturas";
            btnCrearFacturas.TextAlign = ContentAlignment.MiddleLeft;
            btnCrearFacturas.UseVisualStyleBackColor = true;
            btnCrearFacturas.Click += button7_Click;
            // 
            // btnMenuCajero
            // 
            btnMenuCajero.Dock = DockStyle.Top;
            btnMenuCajero.FlatAppearance.BorderSize = 0;
            btnMenuCajero.FlatStyle = FlatStyle.Flat;
            btnMenuCajero.ForeColor = SystemColors.Window;
            btnMenuCajero.Image = Properties.Resources.bill;
            btnMenuCajero.ImageAlign = ContentAlignment.MiddleRight;
            btnMenuCajero.Location = new Point(0, 341);
            btnMenuCajero.Name = "btnMenuCajero";
            btnMenuCajero.Padding = new Padding(10, 0, 0, 0);
            btnMenuCajero.Size = new Size(250, 66);
            btnMenuCajero.TabIndex = 3;
            btnMenuCajero.Text = "Cajero";
            btnMenuCajero.TextAlign = ContentAlignment.MiddleLeft;
            btnMenuCajero.UseVisualStyleBackColor = true;
            btnMenuCajero.Click += button4_Click_1;
            // 
            // panelSubMenuAdministrador
            // 
            panelSubMenuAdministrador.BackColor = Color.FromArgb(35, 36, 34);
            panelSubMenuAdministrador.Controls.Add(btnProductos);
            panelSubMenuAdministrador.Controls.Add(btnCajeros);
            panelSubMenuAdministrador.Controls.Add(btnHistorialFacturas);
            panelSubMenuAdministrador.Dock = DockStyle.Top;
            panelSubMenuAdministrador.Location = new Point(0, 221);
            panelSubMenuAdministrador.Name = "panelSubMenuAdministrador";
            panelSubMenuAdministrador.Size = new Size(250, 120);
            panelSubMenuAdministrador.TabIndex = 2;
            panelSubMenuAdministrador.Paint += panelSubMenuAdministrador_Paint;
            // 
            // btnProductos
            // 
            btnProductos.Dock = DockStyle.Top;
            btnProductos.FlatAppearance.BorderSize = 0;
            btnProductos.FlatAppearance.MouseDownBackColor = Color.FromArgb(11, 114, 110);
            btnProductos.FlatAppearance.MouseOverBackColor = Color.FromArgb(11, 114, 110);
            btnProductos.FlatStyle = FlatStyle.Flat;
            btnProductos.ForeColor = SystemColors.Window;
            btnProductos.Location = new Point(0, 80);
            btnProductos.Name = "btnProductos";
            btnProductos.Padding = new Padding(35, 0, 0, 0);
            btnProductos.Size = new Size(250, 40);
            btnProductos.TabIndex = 4;
            btnProductos.Text = "Productos";
            btnProductos.TextAlign = ContentAlignment.MiddleLeft;
            btnProductos.UseVisualStyleBackColor = true;
            btnProductos.Click += btnProductos_Click;
            // 
            // btnCajeros
            // 
            btnCajeros.Dock = DockStyle.Top;
            btnCajeros.FlatAppearance.BorderSize = 0;
            btnCajeros.FlatAppearance.MouseDownBackColor = Color.FromArgb(11, 114, 110);
            btnCajeros.FlatAppearance.MouseOverBackColor = Color.FromArgb(11, 114, 110);
            btnCajeros.FlatStyle = FlatStyle.Flat;
            btnCajeros.ForeColor = SystemColors.Window;
            btnCajeros.Location = new Point(0, 40);
            btnCajeros.Name = "btnCajeros";
            btnCajeros.Padding = new Padding(35, 0, 0, 0);
            btnCajeros.Size = new Size(250, 40);
            btnCajeros.TabIndex = 3;
            btnCajeros.Text = "Cajeros";
            btnCajeros.TextAlign = ContentAlignment.MiddleLeft;
            btnCajeros.UseVisualStyleBackColor = true;
            btnCajeros.Click += btnCajeros_Click;
            // 
            // btnHistorialFacturas
            // 
            btnHistorialFacturas.Dock = DockStyle.Top;
            btnHistorialFacturas.FlatAppearance.BorderSize = 0;
            btnHistorialFacturas.FlatAppearance.MouseDownBackColor = Color.FromArgb(11, 114, 110);
            btnHistorialFacturas.FlatAppearance.MouseOverBackColor = Color.FromArgb(11, 114, 110);
            btnHistorialFacturas.FlatStyle = FlatStyle.Flat;
            btnHistorialFacturas.ForeColor = SystemColors.Window;
            btnHistorialFacturas.Location = new Point(0, 0);
            btnHistorialFacturas.Name = "btnHistorialFacturas";
            btnHistorialFacturas.Padding = new Padding(35, 0, 0, 0);
            btnHistorialFacturas.Size = new Size(250, 40);
            btnHistorialFacturas.TabIndex = 2;
            btnHistorialFacturas.Text = "Historial Facturas";
            btnHistorialFacturas.TextAlign = ContentAlignment.MiddleLeft;
            btnHistorialFacturas.UseVisualStyleBackColor = true;
            // 
            // btnMenuAdministrador
            // 
            btnMenuAdministrador.Dock = DockStyle.Top;
            btnMenuAdministrador.FlatAppearance.BorderSize = 0;
            btnMenuAdministrador.FlatStyle = FlatStyle.Flat;
            btnMenuAdministrador.ForeColor = SystemColors.Window;
            btnMenuAdministrador.Image = Properties.Resources.administrator;
            btnMenuAdministrador.ImageAlign = ContentAlignment.MiddleRight;
            btnMenuAdministrador.Location = new Point(0, 155);
            btnMenuAdministrador.Name = "btnMenuAdministrador";
            btnMenuAdministrador.Padding = new Padding(10, 0, 0, 0);
            btnMenuAdministrador.Size = new Size(250, 66);
            btnMenuAdministrador.TabIndex = 1;
            btnMenuAdministrador.Text = "Administrador";
            btnMenuAdministrador.TextAlign = ContentAlignment.MiddleLeft;
            btnMenuAdministrador.UseVisualStyleBackColor = true;
            btnMenuAdministrador.Click += btnMenu_Click;
            // 
            // panelLogo
            // 
            panelLogo.BackgroundImage = Properties.Resources.Banner_Inventario1;
            panelLogo.Dock = DockStyle.Top;
            panelLogo.Location = new Point(0, 0);
            panelLogo.Name = "panelLogo";
            panelLogo.Size = new Size(250, 155);
            panelLogo.TabIndex = 0;
            // 
            // panelChildForm
            // 
            panelChildForm.BackColor = Color.FromArgb(26, 28, 28);
            panelChildForm.Controls.Add(pictureBox1);
            panelChildForm.Dock = DockStyle.Fill;
            panelChildForm.Location = new Point(250, 0);
            panelChildForm.Name = "panelChildForm";
            panelChildForm.Size = new Size(684, 561);
            panelChildForm.TabIndex = 1;
            panelChildForm.Paint += panelChildForm_Paint;
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = AnchorStyles.None;
            pictureBox1.Image = Properties.Resources.Inventario_Tienda_Logo;
            pictureBox1.Location = new Point(181, 100);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(346, 346);
            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // Inicio
            // 
            AutoScaleDimensions = new SizeF(8F, 16F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(934, 561);
            Controls.Add(panelChildForm);
            Controls.Add(panelMenuLateral);
            Font = new Font("Verdana", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            MinimumSize = new Size(950, 600);
            Name = "Inicio";
            Text = "Inicio";
            panelMenuLateral.ResumeLayout(false);
            panelSubMenuCajero.ResumeLayout(false);
            panelSubMenuAdministrador.ResumeLayout(false);
            panelChildForm.ResumeLayout(false);
            panelChildForm.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panelMenuLateral;
        private Panel panelSubMenuAdministrador;
        private Button btnMenuAdministrador;
        private Panel panelLogo;
        private Panel panelChildForm;
        private PictureBox pictureBox1;
        private Button btnProductos;
        private Button btnCajeros;
        private Button btnHistorialFacturas;
        private Button button6;
        private Button button5;
        private Panel panelSubMenuCajero;
        private Button btnCrearFacturas;
        private Button btnMenuCajero;
    }
}