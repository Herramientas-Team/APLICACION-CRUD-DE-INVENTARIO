﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using crud;
using Negocios;

namespace Presentacion
{
    public partial class Inicio : Form
    {
        public Inicio()
        {
            InitializeComponent();
            Home_Design();
        }

        private void Home_Design()
        {
            panelSubMenuAdministrador.Visible = false;
            panelSubMenuCajero.Visible = false;
        }

        private void hideSubMenu()
        {
            if (panelSubMenuAdministrador.Visible == true)
                panelSubMenuAdministrador.Visible = false;
            if (panelSubMenuCajero.Visible == true)
                panelSubMenuCajero.Visible = false;
        }

        private void showSubMenu(Panel subMenu)
        {
            if (subMenu.Visible == false)
            {
                hideSubMenu();
                subMenu.Visible = true;
            }
            else
                subMenu.Visible = false;
        }

        #region BotonesMenu
        private void btnMenu_Click(object sender, EventArgs e)
        {
            showSubMenu(panelSubMenuAdministrador);
        }

        private void btnAdmin_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Login());
            hideSubMenu();
        }

        private void btnCajero_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Clientes());
            hideSubMenu();
        }
        #endregion

        private Form activeForm = null;

        private void OpenChildForm(Form childForm)
        {
            if (activeForm != null)
                activeForm.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panelChildForm.Controls.Add(childForm);
            panelChildForm.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }

        private void panelChildForm_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Login());
            hideSubMenu();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            showSubMenu(panelSubMenuCajero);
        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void panelSubMenuAdministrador_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Login());
            hideSubMenu();
        }

        private void btnCajeros_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Cajeros());
            hideSubMenu();
        }

        private void btnProductos_Click(object sender, EventArgs e)
        {
            OpenChildForm(new frmMain());
            hideSubMenu();
        }
    }
}