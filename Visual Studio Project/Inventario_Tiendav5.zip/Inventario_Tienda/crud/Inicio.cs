﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using crud;
using Negocios;

namespace Presentacion
{
    public partial class Inicio : Form
    {
        public Inicio()
        {
            InitializeComponent();
            Home_Design();
            DeshabilitarMenus();
        }

        private void Home_Design()
        {
            panelSubMenuClientes.Visible = false;
            panelSubMenuFacturas.Visible = false;
            panelSubMenuProductos.Visible = false;
            panelSubMenuCategorias.Visible = false;
        }

        private Button Clientes;
        private Button Facturas;
        private Button Productos;
        private Button Categorias;

        private void hideSubMenu()
        {
            if (panelSubMenuClientes.Visible == true)
                panelSubMenuClientes.Visible = false;
            if (panelSubMenuFacturas.Visible == true)
                panelSubMenuFacturas.Visible = false;
            if (panelSubMenuProductos.Visible == true)
                panelSubMenuProductos.Visible = false;
            if (panelSubMenuCategorias.Visible == true)
                panelSubMenuCategorias.Visible = false;
        }

        private void showSubMenu(Panel subMenu)
        {
            if (subMenu.Visible == false)
            {
                hideSubMenu();
                subMenu.Visible = true;
            }
            else
                subMenu.Visible = false;
        }

        private void btnMenuClientes_Click(object sender, EventArgs e)
        {
            if (conUsuario.ObtenerIdUsuarioSesion() != -1) // Verificar si hay sesión iniciada
            {
                showSubMenu(panelSubMenuClientes);
            }
            else
            {
                MessageBox.Show("Debes iniciar sesión para acceder a esta sección.", "Acceso denegado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnMenuFacturas_Click(object sender, EventArgs e)
        {
            if (conUsuario.ObtenerIdUsuarioSesion() != -1) // Verificar si hay sesión iniciada
            {
                showSubMenu(panelSubMenuFacturas);
            }
            else
            {
                MessageBox.Show("Debes iniciar sesión para acceder a esta sección.", "Acceso denegado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnMenuProductos_Click(object sender, EventArgs e)
        {
            if (conUsuario.ObtenerIdUsuarioSesion() != -1) // Verificar si hay sesión iniciada
            {
                showSubMenu(panelSubMenuProductos);
            }
            else
            {
                MessageBox.Show("Debes iniciar sesión para acceder a esta sección.", "Acceso denegado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnMenuCategorias_Click(object sender, EventArgs e)
        {
            if (conUsuario.ObtenerIdUsuarioSesion() != -1) // Verificar si hay sesión iniciada
            {
                showSubMenu(panelSubMenuCategorias);
            }
            else
            {
                MessageBox.Show("Debes iniciar sesión para acceder a esta sección.", "Acceso denegado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnAdmin_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Login());
            hideSubMenu();
        }

        private void btnCajero_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Clientes());
            hideSubMenu();
        }

        private Form activeForm = null;

        private void OpenChildForm(Form childForm)
        {
            if (activeForm != null)
                activeForm.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            //panelChildForm.Controls.Add(childForm);
            //panelChildForm.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }

        private void panelChildForm_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Login());
            hideSubMenu();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            FormHistorialFacturas frm = FormHistorialFacturas.VentanaUnica();
            frm.MdiParent = this;
            frm.Show();
            frm.BringToFront();
        }

        private void panelSubMenuAdministrador_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnIniciarSesion_Click(object sender, EventArgs e)
        {
            Login login = new();
            login.ShowDialog();

            if (conUsuario.ObtenerIdUsuarioSesion() != -1)
            {
                // Ocultar el botón "Iniciar Sesión"
                btnIniciarSesion.Visible = false;

                // Mostrar el botón "Cerrar Sesión"
                btnCerrarSesion.Visible = true;

                // Actualiza los estados de los menús
                Inicio_Load(sender, e);

                // Habilitar los menús
                HabilitarMenus();
            }
        }

        private void btnCajeros_Click(object sender, EventArgs e)
        {
            FormNuevoCliente frm = FormNuevoCliente.VentanaUnica();
            frm.MdiParent = this;
            frm.Show();
            frm.BringToFront();
        }

        private void btnProductos_Click(object sender, EventArgs e)
        {
            FormVerProductos frm = FormVerProductos.VentanaUnica();
            frm.MdiParent = this;
            frm.Show();
            frm.BringToFront();
        }

        private void Inicio_Load(object sender, EventArgs e)
        {
            if (conUsuario.ObtenerIdUsuarioSesion() != -1) // Verificar si hay sesión iniciada
            {
                // Ocultar el botón "Iniciar Sesión"
                btnIniciarSesion.Visible = false;

                // Mostrar el botón "Cerrar Sesión"
                btnCerrarSesion.Visible = true;

                // Habilitar/deshabilitar elementos del menú según el rol
                int rol = conUsuario.ObtenerRolUsuarioSesion();
                if (rol == 1) // Administrador
                {
                    btnMenuClientes.Visible = true;
                    panelSubMenuClientes.Visible = true;
                    btnMenuFacturas.Visible = true;
                    panelSubMenuFacturas.Visible = true;
                    btnMenuProductos.Visible = true;
                    panelSubMenuProductos.Visible = true;
                    btnMenuCategorias.Visible = true;
                    panelSubMenuCategorias.Visible = true;
                    btnHistorialFacturas.Visible = true;
                    // Habilitar todos los formularios (ejemplo)
                    this.Clientes.Enabled = true;
                    this.Facturas.Enabled = true;
                    this.Productos.Enabled = true;
                    this.Categorias.Enabled = true;
                }
                else if (rol == 2) // Cajero
                {
                    btnMenuClientes.Visible = false;
                    btnMenuProductos.Visible = false;
                    btnMenuCategorias.Visible = false;
                    btnMenuFacturas.Visible = true;
                    btnNuevaFactura.Visible = true;
                    btnHistorialFacturas.Visible = false;
                    panelSubMenuFacturas.Size = new Size(233, 48);
                    // Habilitar el formulario "Crear Factura"
                    this.Facturas.Enabled = true;
                    this.Clientes.Enabled = false;
                    this.Productos.Enabled = false;
                    this.Categorias.Enabled = false;
                }
            }
        }

        private void btnCerrarSesion_Click(object sender, EventArgs e)
        {
            // Cierra la sesión del usuario
            conUsuario.CerrarSesion();

            // Muestra el botón "Iniciar Sesión"
            btnIniciarSesion.Visible = true;

            // Oculta el botón "Cerrar Sesión"
            btnCerrarSesion.Visible = false;

            // Deshabilita todos los menús
            Clientes.Enabled = false;
            Facturas.Enabled = false;
            Productos.Enabled = false;
            Categorias.Enabled = false;

            DeshabilitarMenus();
            hideSubMenu();
        }

        private void btnVerClientes_Click(object sender, EventArgs e)
        {
            FormVerClientes frm = FormVerClientes.VentanaUnica();
            frm.MdiParent = this;
            frm.Show();
            frm.BringToFront();
        }

        private void Inicio_Load_1(object sender, EventArgs e)
        {
            foreach (Control ctrl in this.Controls)
            {
                if (ctrl is MdiClient)
                {
                    ctrl.BackColor = Color.FromArgb(28, 29, 29);
                }

            }
        }

        private void btnVerProductos_Click(object sender, EventArgs e)
        {
            FormVerProductos frm = FormVerProductos.VentanaUnica();
            frm.MdiParent = this;
            frm.Show();
            frm.BringToFront();
        }

        // Métodos para habilitar y deshabilitar los menús
        private void HabilitarMenus()
        {
            btnMenuClientes.Enabled = true;
            btnMenuFacturas.Enabled = true;
            btnMenuProductos.Enabled = true;
            btnMenuCategorias.Enabled = true;
        }

        private void DeshabilitarMenus()
        {
            btnMenuClientes.Enabled = false;
            btnMenuFacturas.Enabled = false;
            btnMenuProductos.Enabled = false;
            btnMenuCategorias.Enabled = false;
            hideSubMenu();
        }

        private void btnNuevaFactura_Click(object sender, EventArgs e)
        {
            FormNuevaFactura frm = FormNuevaFactura.VentanaUnica();
            frm.MdiParent = this;
            frm.Show();
            frm.BringToFront();
        }

        private void btnNuevoProducto_Click(object sender, EventArgs e)
        {
            FormNuevoProducto frm = FormNuevoProducto.VentanaUnica();
            frm.MdiParent = this;
            frm.Show();
            frm.BringToFront();
        }

        private void btnVerCategorias_Click(object sender, EventArgs e)
        {
            FormVerCategorias frm = FormVerCategorias.VentanaUnica();
            frm.MdiParent = this;
            frm.Show();
            frm.BringToFront();
        }

        private void btnNuevaCategoria_Click(object sender, EventArgs e)
        {
            FormNuevaCategoria frm = FormNuevaCategoria.VentanaUnica();
            frm.MdiParent = this;
            frm.Show();
            frm.BringToFront();
        }
    }
}