﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentacion
{
    public partial class FormNuevaFactura : Form
    {
        public static FormNuevaFactura instancia = null;

        public static FormNuevaFactura VentanaUnica()   
        {
            if (instancia == null)
            {
                instancia = new FormNuevaFactura();
                return instancia;
            }
            return instancia;
        }

        public FormNuevaFactura()
        {
            InitializeComponent();
        }

        private void FormNuevaFactura_LocationChanged(object sender, EventArgs e)
        {
            if (this.MdiParent != null)
            {
                var parentBounds = this.MdiParent.ClientSize;
                var formBounds = this.Bounds;

                if (formBounds.Left < 0 || formBounds.Top < 0 ||
                    formBounds.Right > parentBounds.Width ||
                    formBounds.Bottom > parentBounds.Height)
                {
                    this.StartPosition = FormStartPosition.Manual;
                    this.Location = new System.Drawing.Point(
                        (this.MdiParent.ClientSize.Width - this.Width) / 2,
                        (this.MdiParent.ClientSize.Height - this.Height) / 2);
                }
            }
        }

        private void FormNuevaFactura_FormClosing(object sender, FormClosingEventArgs e)
        {
            instancia = null;
        }

    }
}
