﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentacion
{
    public partial class FormNuevaCategoria : Form
    {
        public static FormNuevaCategoria instancia = null;

        public static FormNuevaCategoria VentanaUnica()
        {
            if (instancia == null)
            {
                instancia = new FormNuevaCategoria();
                return instancia;
            }
            return instancia;
        }
        public FormNuevaCategoria()
        {
            InitializeComponent();
        }

        private void FormNuevaCategoria_LocationChanged(object sender, EventArgs e)
        {
            if (this.MdiParent != null)
            {
                var parentBounds = this.MdiParent.ClientSize;
                var formBounds = this.Bounds;

                if (formBounds.Left < 0 || formBounds.Top < 0 ||
                    formBounds.Right > parentBounds.Width ||
                    formBounds.Bottom > parentBounds.Height)
                {
                    this.StartPosition = FormStartPosition.Manual;
                    this.Location = new System.Drawing.Point(
                        (this.MdiParent.ClientSize.Width - this.Width) / 2,
                        (this.MdiParent.ClientSize.Height - this.Height) / 2);
                }
            }
        }

        private void FormNuevaCategoria_FormClosing(object sender, FormClosingEventArgs e)
        {
            instancia = null;
        }

    }
}
