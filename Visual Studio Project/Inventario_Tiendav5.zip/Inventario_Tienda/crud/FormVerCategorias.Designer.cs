﻿namespace Presentacion
{
    partial class FormVerCategorias
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            label5 = new Label();
            groupBox2 = new GroupBox();
            btnEliminar = new Button();
            btnActualizar = new Button();
            label2 = new Label();
            txtDireccion = new TextBox();
            txtApellido = new TextBox();
            label1 = new Label();
            btnBuscar = new Button();
            label7 = new Label();
            numericUpdownIdCliente = new NumericUpDown();
            label6 = new Label();
            txtNombre = new TextBox();
            txtCorreo = new TextBox();
            label4 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpdownIdCliente).BeginInit();
            SuspendLayout();
            FormClosing += FormVerCategorias_FormClosing;
            LocationChanged += FormVerCategorias_LocationChanged;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.folder;
            pictureBox1.Location = new Point(439, 26);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(25, 25);
            pictureBox1.TabIndex = 32;
            pictureBox1.TabStop = false;
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.Font = new Font("Impact", 24F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label5.ForeColor = SystemColors.Window;
            label5.Location = new Point(212, 18);
            label5.Name = "label5";
            label5.Size = new Size(223, 39);
            label5.TabIndex = 31;
            label5.Text = "VER CATEGORÍAS";
            // 
            // groupBox2
            // 
            groupBox2.Anchor = AnchorStyles.None;
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(txtCorreo);
            groupBox2.Controls.Add(btnEliminar);
            groupBox2.Controls.Add(btnActualizar);
            groupBox2.Controls.Add(label2);
            groupBox2.Controls.Add(txtDireccion);
            groupBox2.Controls.Add(txtApellido);
            groupBox2.Controls.Add(label1);
            groupBox2.Controls.Add(btnBuscar);
            groupBox2.Controls.Add(label7);
            groupBox2.Controls.Add(numericUpdownIdCliente);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(txtNombre);
            groupBox2.ForeColor = SystemColors.Window;
            groupBox2.Location = new Point(0, 60);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(684, 501);
            groupBox2.TabIndex = 33;
            groupBox2.TabStop = false;
            groupBox2.Text = "Comandos";
            // 
            // btnEliminar
            // 
            btnEliminar.BackColor = Color.Red;
            btnEliminar.Font = new Font("Verdana", 9.75F, FontStyle.Bold);
            btnEliminar.ForeColor = SystemColors.Window;
            btnEliminar.Location = new Point(420, 51);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(95, 32);
            btnEliminar.TabIndex = 41;
            btnEliminar.Text = "Eliminar";
            btnEliminar.UseVisualStyleBackColor = false;
            // 
            // btnActualizar
            // 
            btnActualizar.BackColor = Color.FromArgb(255, 128, 0);
            btnActualizar.Font = new Font("Verdana", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnActualizar.ForeColor = SystemColors.Window;
            btnActualizar.Location = new Point(296, 51);
            btnActualizar.Name = "btnActualizar";
            btnActualizar.Size = new Size(95, 32);
            btnActualizar.TabIndex = 40;
            btnActualizar.Text = "Actualizar";
            btnActualizar.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(475, 105);
            label2.Name = "label2";
            label2.Size = new Size(47, 16);
            label2.TabIndex = 34;
            label2.Text = "Precio";
            // 
            // txtDireccion
            // 
            txtDireccion.Location = new Point(475, 124);
            txtDireccion.Name = "txtDireccion";
            txtDireccion.Size = new Size(186, 23);
            txtDireccion.TabIndex = 33;
            // 
            // txtApellido
            // 
            txtApellido.Location = new Point(250, 124);
            txtApellido.Name = "txtApellido";
            txtApellido.Size = new Size(186, 23);
            txtApellido.TabIndex = 32;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(250, 105);
            label1.Name = "label1";
            label1.Size = new Size(82, 16);
            label1.TabIndex = 31;
            label1.Text = "Descripción";
            // 
            // btnBuscar
            // 
            btnBuscar.BackColor = Color.DimGray;
            btnBuscar.Font = new Font("Verdana", 9.75F, FontStyle.Bold);
            btnBuscar.ForeColor = SystemColors.Window;
            btnBuscar.Location = new Point(167, 51);
            btnBuscar.Name = "btnBuscar";
            btnBuscar.Size = new Size(95, 32);
            btnBuscar.TabIndex = 30;
            btnBuscar.Text = "Buscar";
            btnBuscar.UseVisualStyleBackColor = false;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(22, 36);
            label7.Name = "label7";
            label7.Size = new Size(21, 16);
            label7.TabIndex = 28;
            label7.Text = "ID";
            // 
            // numericUpdownIdCliente
            // 
            numericUpdownIdCliente.Location = new Point(22, 55);
            numericUpdownIdCliente.Name = "numericUpdownIdCliente";
            numericUpdownIdCliente.Size = new Size(98, 23);
            numericUpdownIdCliente.TabIndex = 27;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(22, 105);
            label6.Name = "label6";
            label6.Size = new Size(160, 16);
            label6.TabIndex = 26;
            label6.Text = "Nombre de la categoría";
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(22, 124);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(186, 23);
            txtNombre.TabIndex = 25;
            // 
            // txtCorreo
            // 
            txtCorreo.Location = new Point(250, 208);
            txtCorreo.Name = "txtCorreo";
            txtCorreo.Size = new Size(186, 23);
            txtCorreo.TabIndex = 43;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(250, 189);
            label4.Name = "label4";
            label4.Size = new Size(65, 16);
            label4.TabIndex = 45;
            label4.Text = "Cantidad";
            // 
            // FormVerCategorias
            // 
            AutoScaleDimensions = new SizeF(8F, 16F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(28, 29, 29);
            ClientSize = new Size(684, 561);
            Controls.Add(groupBox2);
            Controls.Add(pictureBox1);
            Controls.Add(label5);
            Font = new Font("Verdana", 9.75F);
            Name = "FormVerCategorias";
            Text = "Ver Categorías";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpdownIdCliente).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Label label5;
        private GroupBox groupBox2;
        private Button btnEliminar;
        private Button btnActualizar;
        private Label label2;
        private TextBox txtDireccion;
        private TextBox txtApellido;
        private Label label1;
        private Button btnBuscar;
        private Label label7;
        private NumericUpDown numericUpdownIdCliente;
        private Label label6;
        private TextBox txtNombre;
        private TextBox txtCorreo;
        private Label label4;
    }
}