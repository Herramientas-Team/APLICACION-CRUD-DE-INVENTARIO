﻿namespace Presentacion
{
    partial class FormNuevaFactura
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            label5 = new Label();
            groupBox2 = new GroupBox();
            label7 = new Label();
            txtId = new TextBox();
            btnAgregar = new Button();
            label3 = new Label();
            txtTelefono = new TextBox();
            txtApellido = new TextBox();
            label1 = new Label();
            label6 = new Label();
            txtNombre = new TextBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.group;
            pictureBox1.Location = new Point(441, 26);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(25, 25);
            pictureBox1.TabIndex = 34;
            pictureBox1.TabStop = false;
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.Font = new Font("Impact", 24F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label5.ForeColor = SystemColors.Window;
            label5.Location = new Point(222, 18);
            label5.Name = "label5";
            label5.Size = new Size(215, 39);
            label5.TabIndex = 33;
            label5.Text = "NUEVA FACTURA";
            label5.TextAlign = ContentAlignment.TopCenter;
            // 
            // groupBox2
            // 
            groupBox2.Anchor = AnchorStyles.None;
            groupBox2.Controls.Add(label7);
            groupBox2.Controls.Add(txtId);
            groupBox2.Controls.Add(btnAgregar);
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(txtTelefono);
            groupBox2.Controls.Add(txtApellido);
            groupBox2.Controls.Add(label1);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(txtNombre);
            groupBox2.ForeColor = SystemColors.Window;
            groupBox2.Location = new Point(0, 60);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(684, 501);
            groupBox2.TabIndex = 35;
            groupBox2.TabStop = false;
            groupBox2.Text = "Comandos";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(22, 42);
            label7.Name = "label7";
            label7.Size = new Size(109, 16);
            label7.TabIndex = 41;
            label7.Text = "ID del producto";
            // 
            // txtId
            // 
            txtId.Location = new Point(22, 61);
            txtId.Name = "txtId";
            txtId.Size = new Size(186, 23);
            txtId.TabIndex = 40;
            // 
            // btnAgregar
            // 
            btnAgregar.BackColor = Color.Lime;
            btnAgregar.Font = new Font("Verdana", 9.75F, FontStyle.Bold);
            btnAgregar.ForeColor = SystemColors.Window;
            btnAgregar.Location = new Point(301, 181);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(95, 32);
            btnAgregar.TabIndex = 39;
            btnAgregar.Text = "Agregar";
            btnAgregar.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(255, 105);
            label3.Name = "label3";
            label3.Size = new Size(125, 16);
            label3.TabIndex = 37;
            label3.Text = "ID de la categoría";
            // 
            // txtTelefono
            // 
            txtTelefono.Location = new Point(255, 124);
            txtTelefono.Name = "txtTelefono";
            txtTelefono.Size = new Size(186, 23);
            txtTelefono.TabIndex = 35;
            // 
            // txtApellido
            // 
            txtApellido.Location = new Point(475, 61);
            txtApellido.Name = "txtApellido";
            txtApellido.Size = new Size(186, 23);
            txtApellido.TabIndex = 32;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(475, 42);
            label1.Name = "label1";
            label1.Size = new Size(133, 16);
            label1.TabIndex = 31;
            label1.Text = "Stock del producto";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(255, 42);
            label6.Name = "label6";
            label6.Size = new Size(144, 16);
            label6.TabIndex = 26;
            label6.Text = "Nombre del producto";
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(255, 61);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(186, 23);
            txtNombre.TabIndex = 25;
            // 
            // FormNuevaFactura
            // 
            AutoScaleDimensions = new SizeF(8F, 16F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(28, 29, 29);
            ClientSize = new Size(684, 561);
            Controls.Add(groupBox2);
            Controls.Add(pictureBox1);
            Controls.Add(label5);
            Font = new Font("Verdana", 9.75F);
            Name = "FormNuevaFactura";
            Text = "Nueva Factura";
            FormClosing += FormNuevaFactura_FormClosing;
            LocationChanged += FormNuevaFactura_LocationChanged;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Label label5;
        private GroupBox groupBox2;
        private Label label7;
        private TextBox txtId;
        private Button btnAgregar;
        private Label label3;
        private TextBox txtTelefono;
        private TextBox txtApellido;
        private Label label1;
        private Label label6;
        private TextBox txtNombre;
    }
}