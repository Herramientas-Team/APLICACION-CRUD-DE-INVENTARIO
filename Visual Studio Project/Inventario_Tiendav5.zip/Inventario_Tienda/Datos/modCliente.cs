﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class modCliente
    {
        private Conexion conexion;

        public modCliente()
        {
            conexion = new Conexion(); // Inicializa la conexión
        }

        public string Id_cliente { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Direccion { get; set; }
        public string Telefono { get; set; }
        public string Correo { get; set; }

        public bool ObtenerClientePorId(string id_cliente)
        {
            bool clienteEncontrado = false;
            try
            {
                using (SqlConnection conn = conexion.AbrirConexion())
                {
                    using (SqlCommand cmd = new SqlCommand("SELECT Nombre, Apellido, Direccion, Telefono, Correo FROM Clientes WHERE Id_cliente = @id_cliente", conn))
                    {
                        cmd.Parameters.AddWithValue("@id_cliente", id_cliente);

                        SqlDataReader reader = cmd.ExecuteReader();
                        if (reader.HasRows)
                        {
                            reader.Read();
                            Nombre = reader["Nombre"].ToString();
                            Apellido = reader["Apellido"].ToString();
                            Direccion = reader["Direccion"].ToString();
                            Telefono = reader["Telefono"].ToString();
                            Correo = reader["Correo"].ToString();
                            clienteEncontrado = true;
                        }
                        reader.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                // Manejo de errores
                Console.WriteLine("Error al obtener cliente por ID: " + ex.Message);
            }
            return clienteEncontrado;
        }

        public bool ActualizarCliente(modCliente cliente)
        {
            bool clienteActualizado = false;
            try
            {
                using (SqlConnection conn = conexion.AbrirConexion())
                {
                    using (SqlCommand cmd = new SqlCommand("UPDATE Clientes SET Nombre = @nombre, Apellido = @apellido, Direccion = @direccion, Telefono = @telefono, Correo = @correo WHERE Id_cliente = @id_cliente", conn))
                    {
                        cmd.Parameters.AddWithValue("@nombre", cliente.Nombre);
                        cmd.Parameters.AddWithValue("@apellido", cliente.Apellido);
                        cmd.Parameters.AddWithValue("@direccion", cliente.Direccion);
                        cmd.Parameters.AddWithValue("@telefono", cliente.Telefono);
                        cmd.Parameters.AddWithValue("@correo", cliente.Correo);
                        cmd.Parameters.AddWithValue("@id_cliente", cliente.Id_cliente);

                        if (cmd.ExecuteNonQuery() > 0)
                        {
                            clienteActualizado = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Manejar errores
                Console.WriteLine("Error al actualizar cliente: " + ex.Message);
            }
            return clienteActualizado;
        }

        // Método para eliminar un cliente
        public bool EliminarCliente(string id_cliente)
        {
            bool clienteEliminado = false;
            try
            {
                using (SqlConnection conn = conexion.AbrirConexion())
                {
                    using (SqlCommand cmd = new SqlCommand("DELETE FROM Clientes WHERE Id_cliente = @id_cliente", conn))
                    {
                        cmd.Parameters.AddWithValue("@id_cliente", id_cliente);

                        if (cmd.ExecuteNonQuery() > 0)
                        {
                            clienteEliminado = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Manejar errores
                Console.WriteLine("Error al eliminar cliente: " + ex.Message);
            }
            return clienteEliminado;
        }

        // Método para agregar un cliente
        public bool AgregarCliente(modCliente cliente)
        {
            bool clienteAgregado = false;
            try
            {
                using (SqlConnection conn = conexion.AbrirConexion())
                {
                    // No generar Id_cliente aquí, ya que se define en modCliente
                    using (SqlCommand cmd = new SqlCommand("INSERT INTO Clientes(Id_cliente, Nombre, Apellido, Direccion, Telefono, Correo) VALUES (@id_cliente, @nombre, @apellido, @direccion, @telefono, @correo)", conn)) 
                    {
                        cmd.Parameters.AddWithValue("@id_cliente", cliente.Id_cliente);
                        cmd.Parameters.AddWithValue("@nombre", cliente.Nombre);
                        cmd.Parameters.AddWithValue("@apellido", cliente.Apellido);
                        cmd.Parameters.AddWithValue("@direccion", cliente.Direccion);
                        cmd.Parameters.AddWithValue("@telefono", cliente.Telefono);
                        cmd.Parameters.AddWithValue("@correo", cliente.Correo);

                        if (cmd.ExecuteNonQuery() > 0)
                        {
                            clienteAgregado = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Manejar errores
                Console.WriteLine("Error al agregar cliente: " + ex.Message);
            }
            return clienteAgregado;
        }

        // Método auxiliar para obtener el último ID insertado
        private string ObtenerUltimoIdInsertado(SqlConnection conn)
        {
            string ultimoId = "";
            try
            {
                using (SqlCommand cmd = new SqlCommand("SELECT SCOPE_IDENTITY()", conn))
                {
                    ultimoId = cmd.ExecuteScalar().ToString();
                }
            }
            catch (Exception ex)
            {
                // Manejar errores
                Console.WriteLine("Error al obtener el último ID insertado: " + ex.Message);
            }
            return ultimoId;
        }
    }
}
