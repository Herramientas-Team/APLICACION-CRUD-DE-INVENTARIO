﻿namespace Presentacion
{
    partial class FormNuevoCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label5 = new Label();
            groupBox2 = new GroupBox();
            label7 = new Label();
            txtId = new TextBox();
            btnAgregar = new Button();
            label4 = new Label();
            label3 = new Label();
            txtCorreo = new TextBox();
            txtTelefono = new TextBox();
            label2 = new Label();
            txtDireccion = new TextBox();
            txtApellido = new TextBox();
            label1 = new Label();
            label6 = new Label();
            txtNombre = new TextBox();
            pictureBox1 = new PictureBox();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.Font = new Font("Impact", 24F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label5.ForeColor = SystemColors.Window;
            label5.Location = new Point(233, 18);
            label5.Name = "label5";
            label5.Size = new Size(201, 39);
            label5.TabIndex = 28;
            label5.Text = "NUEVO CLIENTE";
            label5.TextAlign = ContentAlignment.TopCenter;
            // 
            // groupBox2
            // 
            groupBox2.Anchor = AnchorStyles.None;
            groupBox2.Controls.Add(label7);
            groupBox2.Controls.Add(txtId);
            groupBox2.Controls.Add(btnAgregar);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(txtCorreo);
            groupBox2.Controls.Add(txtTelefono);
            groupBox2.Controls.Add(label2);
            groupBox2.Controls.Add(txtDireccion);
            groupBox2.Controls.Add(txtApellido);
            groupBox2.Controls.Add(label1);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(txtNombre);
            groupBox2.ForeColor = SystemColors.Window;
            groupBox2.Location = new Point(0, 60);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(684, 501);
            groupBox2.TabIndex = 29;
            groupBox2.TabStop = false;
            groupBox2.Text = "Comandos";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(22, 42);
            label7.Name = "label7";
            label7.Size = new Size(97, 16);
            label7.TabIndex = 41;
            label7.Text = "ID del usuario";
            // 
            // txtId
            // 
            txtId.Location = new Point(22, 61);
            txtId.Name = "txtId";
            txtId.Size = new Size(186, 23);
            txtId.TabIndex = 40;
            // 
            // btnAgregar
            // 
            btnAgregar.BackColor = Color.Lime;
            btnAgregar.Font = new Font("Verdana", 9.75F, FontStyle.Bold);
            btnAgregar.ForeColor = SystemColors.Window;
            btnAgregar.Location = new Point(307, 181);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(95, 32);
            btnAgregar.TabIndex = 39;
            btnAgregar.Text = "Agregar";
            btnAgregar.UseVisualStyleBackColor = false;
            btnAgregar.Click += btnAgregar_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(475, 105);
            label4.Name = "label4";
            label4.Size = new Size(50, 16);
            label4.TabIndex = 38;
            label4.Text = "Correo";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(255, 105);
            label3.Name = "label3";
            label3.Size = new Size(63, 16);
            label3.TabIndex = 37;
            label3.Text = "Teléfono";
            // 
            // txtCorreo
            // 
            txtCorreo.Location = new Point(475, 124);
            txtCorreo.Name = "txtCorreo";
            txtCorreo.Size = new Size(186, 23);
            txtCorreo.TabIndex = 36;
            // 
            // txtTelefono
            // 
            txtTelefono.Location = new Point(255, 124);
            txtTelefono.Name = "txtTelefono";
            txtTelefono.Size = new Size(186, 23);
            txtTelefono.TabIndex = 35;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(22, 105);
            label2.Name = "label2";
            label2.Size = new Size(67, 16);
            label2.TabIndex = 34;
            label2.Text = "Dirección";
            // 
            // txtDireccion
            // 
            txtDireccion.Location = new Point(22, 124);
            txtDireccion.Name = "txtDireccion";
            txtDireccion.Size = new Size(186, 23);
            txtDireccion.TabIndex = 33;
            // 
            // txtApellido
            // 
            txtApellido.Location = new Point(475, 61);
            txtApellido.Name = "txtApellido";
            txtApellido.Size = new Size(186, 23);
            txtApellido.TabIndex = 32;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(475, 42);
            label1.Name = "label1";
            label1.Size = new Size(57, 16);
            label1.TabIndex = 31;
            label1.Text = "Apellido";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(255, 42);
            label6.Name = "label6";
            label6.Size = new Size(56, 16);
            label6.TabIndex = 26;
            label6.Text = "Nombre";
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(255, 61);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(186, 23);
            txtNombre.TabIndex = 25;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.group;
            pictureBox1.Location = new Point(441, 26);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(25, 25);
            pictureBox1.TabIndex = 30;
            pictureBox1.TabStop = false;
            // 
            // FormNuevoCliente
            // 
            AutoScaleDimensions = new SizeF(8F, 16F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(28, 29, 29);
            ClientSize = new Size(684, 561);
            Controls.Add(pictureBox1);
            Controls.Add(groupBox2);
            Controls.Add(label5);
            Font = new Font("Verdana", 9.75F);
            Name = "FormNuevoCliente";
            Text = "Nuevo Cliente";
            FormClosing += FormNuevoCliente_FormClosing;
            LocationChanged += FormNuevoCliente_LocationChanged;
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label5;
        private GroupBox groupBox2;
        private Button btnAgregar;
        private Label label4;
        private Label label3;
        private TextBox txtCorreo;
        private TextBox txtTelefono;
        private Label label2;
        private TextBox txtDireccion;
        private TextBox txtApellido;
        private Label label1;
        private Label label6;
        private TextBox txtNombre;
        private TextBox txtId;
        private Label label7;
        private PictureBox pictureBox1;
    }
}