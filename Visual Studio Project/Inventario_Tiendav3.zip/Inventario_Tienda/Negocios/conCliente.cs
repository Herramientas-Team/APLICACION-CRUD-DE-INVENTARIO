﻿using Datos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocios
{
    public class conCliente
    {
        public modCliente cliente;

        public conCliente()
        {
            cliente = new modCliente();
        }

        public bool ObtenerClientePorId(string id_cliente)
        {
            return cliente.ObtenerClientePorId(id_cliente);
        }

        public bool ActualizarCliente(modCliente cliente)
        {
            return cliente.ActualizarCliente(cliente);
        }

        public bool EliminarCliente(string id_cliente)
        {
            return cliente.EliminarCliente(id_cliente);
        }

        public bool AgregarCliente(modCliente cliente)
        {
            return cliente.AgregarCliente(cliente);
        }
    }
}
