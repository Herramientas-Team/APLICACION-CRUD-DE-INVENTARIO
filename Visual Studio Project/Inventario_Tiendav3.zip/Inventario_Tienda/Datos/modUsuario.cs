﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace Datos
{
    public class modUsuario
    {
        private Conexion conexion; // Objeto para la conexión a la base de datos

        public modUsuario()
        {
            conexion = new Conexion(); // Inicializa la conexión
        }

        public int Id_usuario { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Contrasena { get; set; }
        public int Id_rol { get; set; }

        // Valida las credenciales del usuario en la base de datos
        public bool ValidarCredenciales(string usuario, string contraseña)
        {
            bool validado = false;
            try
            {
                using (SqlConnection conn = conexion.AbrirConexion())
                {
                    using (SqlCommand cmd = new SqlCommand("SELECT Id_usuario FROM Usuario WHERE Nombre = @usuario AND Contrasena = @contrasena", conn))
                    {
                        cmd.Parameters.AddWithValue("@usuario", usuario);
                        cmd.Parameters.AddWithValue("@contrasena", contraseña);

                        SqlDataReader reader = cmd.ExecuteReader();
                        if (reader.HasRows)
                        {
                            validado = true;
                        }
                        reader.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                // Manejar errores
                Console.WriteLine("Error al validar credenciales: " + ex.Message);
            }
            return validado;
        }

        // Obtiene el ID del usuario después de la validación
        public int ObtenerIdUsuario(string usuario, string contraseña)
        {
            int idUsuario = -1;
            try
            {
                using (SqlConnection conn = conexion.AbrirConexion())
                {
                    using (SqlCommand cmd = new SqlCommand("SELECT Id_usuario FROM Usuario WHERE Nombre = @usuario AND Contrasena = @contrasena", conn))
                    {
                        cmd.Parameters.AddWithValue("@usuario", usuario);
                        cmd.Parameters.AddWithValue("@contrasena", contraseña);

                        SqlDataReader reader = cmd.ExecuteReader();
                        if (reader.HasRows)
                        {
                            reader.Read();
                            idUsuario = Convert.ToInt32(reader["Id_usuario"]);
                        }
                        reader.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                // Manejo de errores
                Console.WriteLine("Error al obtener el ID del usuario: " + ex.Message);
            }
            return idUsuario;
        }

        // Obtiene el rol del usuario
        public int ObtenerRol()
        {
            int rol = -1;
            try
            {
                using (SqlConnection conn = conexion.AbrirConexion())
                {
                    using (SqlCommand cmd = new SqlCommand("SELECT Id_rol FROM Usuario WHERE Id_usuario = @id_usuario", conn))
                    {
                        cmd.Parameters.AddWithValue("@id_usuario", Id_usuario);

                        SqlDataReader reader = cmd.ExecuteReader();
                        if (reader.HasRows)
                        {
                            reader.Read();
                            rol = Convert.ToInt32(reader["Id_rol"]);
                        }
                        reader.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                // Manejo de errores
                Console.WriteLine("Error al obtener el rol del usuario: " + ex.Message);
            }
            return rol;
        }
    }
}
