﻿using Datos;
using Negocios;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentacion
{
    public partial class FormNuevoCliente : Form
    {

        public static FormNuevoCliente instancia = null;

        public static FormNuevoCliente VentanaUnica()
        {
            if (instancia == null)
            {
                instancia = new FormNuevoCliente();
                return instancia;
            }
            return instancia;
        }

        public FormNuevoCliente()
        {
            InitializeComponent();
        }

        private void FormNuevoCliente_LocationChanged(object sender, EventArgs e)
        {
            if (this.MdiParent != null)
            {
                var parentBounds = this.MdiParent.ClientSize;
                var formBounds = this.Bounds;

                if (formBounds.Left < 0 || formBounds.Top < 0 ||
                    formBounds.Right > parentBounds.Width ||
                    formBounds.Bottom > parentBounds.Height)
                {
                    this.StartPosition = FormStartPosition.Manual;
                    this.Location = new System.Drawing.Point(
                        (this.MdiParent.ClientSize.Width - this.Width) / 2,
                        (this.MdiParent.ClientSize.Height - this.Height) / 2);
                }
            }
        }

        private void FormNuevoCliente_FormClosing(object sender, FormClosingEventArgs e)
        {
            instancia = null;
        }


        private void btnAgregar_Click(object sender, EventArgs e)
        {
            // Validar que todos los campos estén llenos
            if (string.IsNullOrEmpty(txtNombre.Text) ||
                string.IsNullOrEmpty(txtId.Text) ||
                string.IsNullOrEmpty(txtApellido.Text) ||
                string.IsNullOrEmpty(txtDireccion.Text) ||
                string.IsNullOrEmpty(txtTelefono.Text) ||
                string.IsNullOrEmpty(txtCorreo.Text))
            {
                MessageBox.Show("Por favor, completa todos los campos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Agregar el cliente
            conCliente clienteService = new conCliente();
            modCliente cliente = new modCliente
            {
                Id_cliente = txtId.Text,
                Nombre = txtNombre.Text,
                Apellido = txtApellido.Text,
                Direccion = txtDireccion.Text,
                Telefono = txtTelefono.Text,
                Correo = txtCorreo.Text
            };

            if (clienteService.AgregarCliente(cliente))
            {
                MessageBox.Show($"Cliente {cliente.Id_cliente} creado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                // Limpiar los campos del formulario
                LimpiarCampos();
            }
            else
            {
                MessageBox.Show("Error al crear el cliente.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void LimpiarCampos()
        {
            txtNombre.Text = string.Empty;
            txtApellido.Text = string.Empty;
            txtDireccion.Text = string.Empty;
            txtTelefono.Text = string.Empty;
            txtCorreo.Text = string.Empty;
        }
    }
}
