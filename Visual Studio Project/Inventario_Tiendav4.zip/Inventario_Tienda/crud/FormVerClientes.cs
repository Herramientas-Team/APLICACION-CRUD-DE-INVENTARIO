﻿using Datos;
using Negocios;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentacion
{
    public partial class FormVerClientes : Form
    {
        public static FormVerClientes instancia = null;

        public static FormVerClientes VentanaUnica()
        {
            if (instancia == null)
            {
                instancia = new FormVerClientes();
                return instancia;
            }
            return instancia;
        }

        public FormVerClientes()
        {
            InitializeComponent();
        }

        private void FormVerClientes_LocationChanged(object sender, EventArgs e)
        {
            // Asegurarse de que el formulario no se salga del MDI
            if (this.MdiParent != null)
            {
                var parentBounds = this.MdiParent.ClientSize;
                var formBounds = this.Bounds;

                // Verificar si el formulario está fuera del área visible del MDI
                if (formBounds.Left < 0 || formBounds.Top < 0 ||
                    formBounds.Right > parentBounds.Width ||
                    formBounds.Bottom > parentBounds.Height)
                {
                    // Reposicionar al centro del MDI
                    this.StartPosition = FormStartPosition.Manual;
                    this.Location = new System.Drawing.Point(
                        (this.MdiParent.ClientSize.Width - this.Width) / 2,
                        (this.MdiParent.ClientSize.Height - this.Height) / 2);
                }
            }
        }
        private void FormVerClientes_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Establecer la instancia a null para permitir la creación de una nueva
            instancia = null;
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            string id_cliente = numericUpdownIdCliente.Value.ToString();

            // Buscar el cliente por ID
            conCliente clienteService = new conCliente();
            if (clienteService.ObtenerClientePorId(id_cliente))
            {
                // Mostrar la información del cliente
                txtNombre.Text = clienteService.cliente.Nombre;
                txtApellido.Text = clienteService.cliente.Apellido;
                txtDireccion.Text = clienteService.cliente.Direccion;
                txtTelefono.Text = clienteService.cliente.Telefono;
                txtCorreo.Text = clienteService.cliente.Correo;
            }
            else
            {
                // Mostrar un mensaje de error
                MessageBox.Show("Cliente no encontrado.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                LimpiarCampos();
            }
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            string id_cliente = numericUpdownIdCliente.Value.ToString();

            // Validar que el ID sea diferente de 0
            if (numericUpdownIdCliente.Value == 0)
            {
                MessageBox.Show("Por favor, selecciona un ID válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validar que todos los campos estén llenos
            if (string.IsNullOrEmpty(txtNombre.Text) ||
                string.IsNullOrEmpty(txtApellido.Text) ||
                string.IsNullOrEmpty(txtDireccion.Text) ||
                string.IsNullOrEmpty(txtTelefono.Text) ||
                string.IsNullOrEmpty(txtCorreo.Text))
            {
                MessageBox.Show("Por favor, completa todos los campos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Actualizar el cliente
            conCliente clienteService = new conCliente();
            modCliente cliente = new modCliente
            {
                Id_cliente = id_cliente,
                Nombre = txtNombre.Text,
                Apellido = txtApellido.Text,
                Direccion = txtDireccion.Text,
                Telefono = txtTelefono.Text,
                Correo = txtCorreo.Text
            };

            if (clienteService.ActualizarCliente(cliente))
            {
                MessageBox.Show($"Cliente {id_cliente} actualizado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                // Limpiar los campos del formulario
                LimpiarCampos();
            }
            else
            {
                MessageBox.Show("Error al actualizar el cliente.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            string id_cliente = numericUpdownIdCliente.Value.ToString();

            // Validar que el ID sea diferente de 0
            if (numericUpdownIdCliente.Value == 0)
            {
                MessageBox.Show("Por favor, selecciona un ID válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Confirmar la eliminación
            if (MessageBox.Show($"¿Estás seguro de que quieres eliminar el cliente {id_cliente}?", "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                // Eliminar el cliente
                conCliente clienteService = new conCliente();
                if (clienteService.EliminarCliente(id_cliente))
                {
                    MessageBox.Show($"Cliente {id_cliente} eliminado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    // Limpiar los campos del formulario
                    LimpiarCampos();
                }
                else
                {
                    MessageBox.Show("Error al eliminar el cliente.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            // Validar que todos los campos estén llenos
            if (string.IsNullOrEmpty(txtNombre.Text) ||
                string.IsNullOrEmpty(txtApellido.Text) ||
                string.IsNullOrEmpty(txtDireccion.Text) ||
                string.IsNullOrEmpty(txtTelefono.Text) ||
                string.IsNullOrEmpty(txtCorreo.Text))
            {
                MessageBox.Show("Por favor, completa todos los campos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Agregar el cliente
            conCliente clienteService = new conCliente();
            modCliente cliente = new modCliente
            {
                Nombre = txtNombre.Text,
                Apellido = txtApellido.Text,
                Direccion = txtDireccion.Text,
                Telefono = txtTelefono.Text,
                Correo = txtCorreo.Text
            };

            if (clienteService.AgregarCliente(cliente))
            {
                MessageBox.Show($"Cliente {cliente.Id_cliente} creado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                // Limpiar los campos del formulario
                LimpiarCampos();
            }
            else
            {
                MessageBox.Show("Error al crear el cliente.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LimpiarCampos()
        {
            txtNombre.Text = string.Empty;
            txtApellido.Text = string.Empty;
            txtDireccion.Text = string.Empty;
            txtTelefono.Text = string.Empty;
            txtCorreo.Text = string.Empty;
            numericUpdownIdCliente.Value = 0;
        }
    }
}
