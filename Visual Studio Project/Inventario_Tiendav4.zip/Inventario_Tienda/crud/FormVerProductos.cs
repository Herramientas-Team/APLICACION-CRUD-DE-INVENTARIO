﻿using Datos;
using Negocios;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentacion
{
    public partial class FormVerProductos : Form
    {

        public static FormVerProductos instancia = null;

        public static FormVerProductos VentanaUnica()
        {
            if (instancia == null)
            {
                instancia = new FormVerProductos();
                return instancia;
            }
            return instancia;
        }

        public FormVerProductos()
        {
            InitializeComponent();
        }

        private void FormVerProductos_LocationChanged(object sender, EventArgs e)
        {
            if (this.MdiParent != null)
            {
                var parentBounds = this.MdiParent.ClientSize;
                var formBounds = this.Bounds;

                if (formBounds.Left < 0 || formBounds.Top < 0 ||
                    formBounds.Right > parentBounds.Width ||
                    formBounds.Bottom > parentBounds.Height)
                {
                    this.StartPosition = FormStartPosition.Manual;
                    this.Location = new System.Drawing.Point(
                        (this.MdiParent.ClientSize.Width - this.Width) / 2,
                        (this.MdiParent.ClientSize.Height - this.Height) / 2);
                }
            }
        }
        private void FormVerProductos_FormClosing(object sender, FormClosingEventArgs e)
        {
            instancia = null;
        }

        private void FormVerProductos_Load(object sender, EventArgs e)
        {

        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            string id_producto = numericUpdownIdProducto.Value.ToString();

            conProducto productoService = new conProducto();
            if (productoService.ObtenerProductoPorId(id_producto))
            {
                txtNombre_producto.Text = productoService.producto.Nombre_producto;
                txtStock.Text = productoService.producto.Stock;
                txtCategoria.Text = productoService.producto.Id_categoria;
            }
            else
            {
                // Mostrar un mensaje de error
                MessageBox.Show("Producto no encontrado.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                LimpiarCampos();
            }
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            string id_producto = numericUpdownIdProducto.Value.ToString();

            // Validar que el ID sea diferente de 0
            if (numericUpdownIdProducto.Value == 0)
            {
                MessageBox.Show("Por favor, selecciona un ID válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validar que todos los campos estén llenos
            if (string.IsNullOrEmpty(txtNombre_producto.Text) ||
                string.IsNullOrEmpty(txtStock.Text) ||
                string.IsNullOrEmpty(txtCategoria.Text))
            {
                MessageBox.Show("Por favor, completa todos los campos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            conProducto productoService = new conProducto();
            modProducto producto = new modProducto
            {
                Id_producto = id_producto,
                Nombre_producto = txtNombre_producto.Text,
                Stock = txtStock.Text,
                Id_categoria = txtCategoria.Text
            };

            if (productoService.ActualizarProducto(producto))
            {
                MessageBox.Show($"Producto {id_producto} actualizado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                // Limpiar los campos del formulario
                LimpiarCampos();
            }
            else
            {
                MessageBox.Show("Error al actualizar el producto.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            string id_producto = numericUpdownIdProducto.Value.ToString();

            // Validar que el ID sea diferente de 0
            if (numericUpdownIdProducto.Value == 0)
            {
                MessageBox.Show("Por favor, selecciona un ID válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Confirmar la eliminación
            if (MessageBox.Show($"¿Estás seguro de que quieres eliminar el producto {id_producto}?", "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                conProducto productoService = new conProducto();
                if (productoService.EliminarProducto(id_producto))
                {
                    MessageBox.Show($"Producto {id_producto} eliminado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    // Limpiar los campos del formulario
                    LimpiarCampos();
                }
                else
                {
                    MessageBox.Show("Error al eliminar el producto.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            // Validar que todos los campos estén llenos
            if (string.IsNullOrEmpty(txtNombre_producto.Text) ||
                string.IsNullOrEmpty(txtStock.Text) ||
                string.IsNullOrEmpty(txtCategoria.Text))
            {
                MessageBox.Show("Por favor, completa todos los campos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            conProducto productoService = new conProducto();
            modProducto producto = new modProducto
            {
                Nombre_producto = txtNombre_producto.Text,
                Stock = txtStock.Text,
                Id_categoria = txtCategoria.Text
            };

            if (productoService.AgregarProducto(producto))
            {
                MessageBox.Show($"Producto {producto.Id_producto} creado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                // Limpiar los campos del formulario
                LimpiarCampos();
            }
            else
            {
                MessageBox.Show("Error al crear el producto.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LimpiarCampos()
        {
            txtNombre_producto.Text = string.Empty;
            txtStock.Text = string.Empty;
            txtCategoria.Text = string.Empty;
            numericUpdownIdProducto.Value = 0;
        }
    }
}
