﻿namespace Presentacion
{
    partial class FormVerProductos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            label5 = new Label();
            groupBox2 = new GroupBox();
            btnEliminar = new Button();
            btnActualizar = new Button();
            label2 = new Label();
            txtCategoria = new TextBox();
            txtStock = new TextBox();
            label1 = new Label();
            btnBuscar = new Button();
            label7 = new Label();
            numericUpdownIdProducto = new NumericUpDown();
            label6 = new Label();
            txtNombre_producto = new TextBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpdownIdProducto).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.product;
            pictureBox1.Location = new Point(444, 26);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(25, 25);
            pictureBox1.TabIndex = 30;
            pictureBox1.TabStop = false;
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.Font = new Font("Impact", 24F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label5.ForeColor = SystemColors.Window;
            label5.Location = new Point(218, 18);
            label5.Name = "label5";
            label5.Size = new Size(222, 39);
            label5.TabIndex = 29;
            label5.Text = "VER PRODUCTOS";
            // 
            // groupBox2
            // 
            groupBox2.Anchor = AnchorStyles.None;
            groupBox2.Controls.Add(btnEliminar);
            groupBox2.Controls.Add(btnActualizar);
            groupBox2.Controls.Add(label2);
            groupBox2.Controls.Add(txtCategoria);
            groupBox2.Controls.Add(txtStock);
            groupBox2.Controls.Add(label1);
            groupBox2.Controls.Add(btnBuscar);
            groupBox2.Controls.Add(label7);
            groupBox2.Controls.Add(numericUpdownIdProducto);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(txtNombre_producto);
            groupBox2.ForeColor = SystemColors.Window;
            groupBox2.Location = new Point(0, 60);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(684, 501);
            groupBox2.TabIndex = 31;
            groupBox2.TabStop = false;
            groupBox2.Text = "Comandos";
            // 
            // btnEliminar
            // 
            btnEliminar.BackColor = Color.Red;
            btnEliminar.Font = new Font("Verdana", 9.75F, FontStyle.Bold);
            btnEliminar.ForeColor = SystemColors.Window;
            btnEliminar.Location = new Point(420, 51);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(95, 32);
            btnEliminar.TabIndex = 41;
            btnEliminar.Text = "Eliminar";
            btnEliminar.UseVisualStyleBackColor = false;
            // 
            // btnActualizar
            // 
            btnActualizar.BackColor = Color.FromArgb(255, 128, 0);
            btnActualizar.Font = new Font("Verdana", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnActualizar.ForeColor = SystemColors.Window;
            btnActualizar.Location = new Point(296, 51);
            btnActualizar.Name = "btnActualizar";
            btnActualizar.Size = new Size(95, 32);
            btnActualizar.TabIndex = 40;
            btnActualizar.Text = "Actualizar";
            btnActualizar.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(475, 105);
            label2.Name = "label2";
            label2.Size = new Size(126, 16);
            label2.TabIndex = 34;
            label2.Text = "ID de la Categoría";
            // 
            // txtCategoria
            // 
            txtCategoria.Location = new Point(475, 124);
            txtCategoria.Name = "txtCategoria";
            txtCategoria.Size = new Size(186, 23);
            txtCategoria.TabIndex = 33;
            // 
            // txtStock
            // 
            txtStock.Location = new Point(250, 124);
            txtStock.Name = "txtStock";
            txtStock.Size = new Size(186, 23);
            txtStock.TabIndex = 32;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(250, 105);
            label1.Name = "label1";
            label1.Size = new Size(45, 16);
            label1.TabIndex = 31;
            label1.Text = "Stock";
            // 
            // btnBuscar
            // 
            btnBuscar.BackColor = Color.DimGray;
            btnBuscar.Font = new Font("Verdana", 9.75F, FontStyle.Bold);
            btnBuscar.ForeColor = SystemColors.Window;
            btnBuscar.Location = new Point(167, 51);
            btnBuscar.Name = "btnBuscar";
            btnBuscar.Size = new Size(95, 32);
            btnBuscar.TabIndex = 30;
            btnBuscar.Text = "Buscar";
            btnBuscar.UseVisualStyleBackColor = false;
            btnBuscar.Click += btnBuscar_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(22, 36);
            label7.Name = "label7";
            label7.Size = new Size(21, 16);
            label7.TabIndex = 28;
            label7.Text = "ID";
            // 
            // numericUpdownIdProducto
            // 
            numericUpdownIdProducto.Location = new Point(22, 55);
            numericUpdownIdProducto.Name = "numericUpdownIdProducto";
            numericUpdownIdProducto.Size = new Size(98, 23);
            numericUpdownIdProducto.TabIndex = 27;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(22, 105);
            label6.Name = "label6";
            label6.Size = new Size(144, 16);
            label6.TabIndex = 26;
            label6.Text = "Nombre del producto";
            // 
            // txtNombre_producto
            // 
            txtNombre_producto.Location = new Point(22, 124);
            txtNombre_producto.Name = "txtNombre_producto";
            txtNombre_producto.Size = new Size(186, 23);
            txtNombre_producto.TabIndex = 25;
            // 
            // FormVerProductos
            // 
            AutoScaleDimensions = new SizeF(8F, 16F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(28, 29, 29);
            ClientSize = new Size(684, 561);
            Controls.Add(groupBox2);
            Controls.Add(pictureBox1);
            Controls.Add(label5);
            Font = new Font("Verdana", 9.75F);
            Name = "FormVerProductos";
            Text = "Ver Productos";
            FormClosing += FormVerProductos_FormClosing;
            Load += FormVerProductos_Load;
            LocationChanged += FormVerProductos_LocationChanged;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpdownIdProducto).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Label label5;
        private GroupBox groupBox2;
        private Button btnEliminar;
        private Button btnActualizar;
        private Label label2;
        private TextBox txtCategoria;
        private TextBox txtStock;
        private Label label1;
        private Button btnBuscar;
        private Label label7;
        private NumericUpDown numericUpdownIdProducto;
        private Label label6;
        private TextBox txtNombre_producto;
    }
}