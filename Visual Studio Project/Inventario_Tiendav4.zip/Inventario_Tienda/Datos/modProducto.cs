﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class modProducto
    {
        private Conexion conexion;

        public modProducto()
        {
            conexion = new Conexion();
        }

        public string Id_producto { get; set; }
        public string Nombre_producto { get; set; }
        public string Stock { get; set; }
        public string Id_categoria { get; set; }

        public bool ObtenerProductoPorId(string Id_producto)
        {
            bool productoEncontrado = false;
            try
            {
                using (SqlConnection conn = conexion.AbrirConexion())
                {
                    using (SqlCommand cmd = new SqlCommand("SELECT Id_producto, Nombre_producto, Stock, Id_categoria FROM Productos WHERE Id_producto = @id_producto", conn))
                    {
                        cmd.Parameters.AddWithValue("@id_producto", Id_producto);

                        SqlDataReader reader = cmd.ExecuteReader();
                        if (reader.HasRows)
                        {
                            reader.Read();
                            Nombre_producto = reader["Nombre"].ToString();
                            Stock = reader["Apellido"].ToString();
                            Id_categoria = reader["Direccion"].ToString();
                            productoEncontrado = true;
                        }
                        reader.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                // Manejo de errores
                Console.WriteLine("Error al obtener el producto por ID: " + ex.Message);
            }
            return productoEncontrado;
        }

        public bool ActualizarProducto(modProducto producto)
        {
            bool productoActualizado = false;
            try
            {
                using (SqlConnection conn = conexion.AbrirConexion())
                {
                    using (SqlCommand cmd = new SqlCommand("UPDATE Productos SET Nombre_producto = @nombre_producto, Stock = @stock, Id_categoria = @id_categoria WHERE Id_producto = @id_producto", conn))
                    {
                        cmd.Parameters.AddWithValue("@nombre_producto", producto.Nombre_producto);
                        cmd.Parameters.AddWithValue("@stock", producto.Stock);
                        cmd.Parameters.AddWithValue("@id_categoria", producto.Id_categoria);

                        if (cmd.ExecuteNonQuery() > 0)
                        {
                            productoActualizado = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Manejar errores
                Console.WriteLine("Error al actualizar el producto: " + ex.Message);
            }
            return productoActualizado;
        }

        public bool EliminarProducto(string id_producto)
        {
            bool productoEliminado = false;
            try
            {
                using (SqlConnection conn = conexion.AbrirConexion())
                {
                    using (SqlCommand cmd = new SqlCommand("DELETE FROM Productos WHERE Id_producto = @id_producto", conn))
                    {
                        cmd.Parameters.AddWithValue("@id_producto", id_producto);

                        if (cmd.ExecuteNonQuery() > 0)
                        {
                            productoEliminado = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Manejar errores
                Console.WriteLine("Error al eliminar el producto: " + ex.Message);
            }
            return productoEliminado;
        }

        public bool AgregarProducto(modProducto producto)
        {
            bool productoAgregado = false;
            try
            {
                using (SqlConnection conn = conexion.AbrirConexion())
                {
                    
                    using (SqlCommand cmd = new SqlCommand("INSERT INTO Productos(Id_producto, Nombre_producto, Stock, Id_categoria) VALUES (@id_producto, @nombre_producto, @stock, @id_categoria)", conn))
                    {
                        cmd.Parameters.AddWithValue("@id_producto", producto.Id_producto);
                        cmd.Parameters.AddWithValue("@nombre", producto.Nombre_producto);
                        cmd.Parameters.AddWithValue("@apellido", producto.Stock);
                        cmd.Parameters.AddWithValue("@direccion", producto.Id_categoria);

                        if (cmd.ExecuteNonQuery() > 0)
                        {
                            productoAgregado = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Manejar errores
                Console.WriteLine("Error al agregar cliente: " + ex.Message);
            }
            return productoAgregado;
        }

        private string ObtenerUltimoIdInsertado(SqlConnection conn)
        {
            string ultimoId = "";
            try
            {
                using (SqlCommand cmd = new SqlCommand("SELECT SCOPE_IDENTITY()", conn))
                {
                    ultimoId = cmd.ExecuteScalar().ToString();
                }
            }
            catch (Exception ex)
            {
                // Manejar errores
                Console.WriteLine("Error al obtener el último ID insertado: " + ex.Message);
            }
            return ultimoId;
        }
    }
}
