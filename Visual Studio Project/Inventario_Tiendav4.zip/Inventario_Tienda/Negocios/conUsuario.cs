﻿using Datos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace Negocios
{
    public class conUsuario
    {
        private Conexion conexion; // Objeto para la conexión a la base de datos
        private modUsuario usuario; // Objeto para la clase Usuario
        private static int IdUsuarioSesion = -1; // Variable global para guardar el ID del usuario
        private static int RolUsuarioSesion = -1; // Variable global para guardar el rol

        public conUsuario()
        {
            usuario = new modUsuario(); // Inicializa la clase Usuario
            conexion = new Conexion(); // Inicializa la conexión
        }

        // Maneja el inicio de sesión del usuario
        public bool IniciarSesion(string usuarioIngresado, string contraseña)
        {
            bool sesionIniciada = false;
            try
            {
                using (SqlConnection conn = conexion.AbrirConexion())
                {
                    // Consulta la base de datos para validar las credenciales
                    using (SqlCommand cmd = new SqlCommand("SELECT Id_usuario, Id_rol FROM Usuario WHERE Nombre = @usuario AND Contrasena = @contraseña", conn))
                    {
                        cmd.Parameters.AddWithValue("@usuario", usuarioIngresado);
                        cmd.Parameters.AddWithValue("@contraseña", contraseña);

                        SqlDataReader reader = cmd.ExecuteReader();

                        if (reader.HasRows)
                        {
                            // Credenciales válidas
                            reader.Read();

                            // Obtener el ID del usuario y el rol
                            IdUsuarioSesion = Convert.ToInt32(reader["Id_usuario"]);
                            RolUsuarioSesion = Convert.ToInt32(reader["Id_rol"]);

                            sesionIniciada = true;
                        }
                        else
                        {
                            // Credenciales inválidas
                            Console.WriteLine("Credenciales inválidas");
                        }

                        reader.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                // Manejo de errores
                Console.WriteLine("Error al iniciar sesión: " + ex.Message);
            }
            return sesionIniciada;
        }

        // Obtener el ID del usuario en sesión
        public static int ObtenerIdUsuarioSesion()
        {
            return IdUsuarioSesion;
        }

        // Obtener el rol del usuario en sesión
        public static int ObtenerRolUsuarioSesion()
        {
            return RolUsuarioSesion;
        }

        // Cerrar sesión
        public static void CerrarSesion()
        {
            IdUsuarioSesion = -1; // Restablecer la variable
            RolUsuarioSesion = -1; // Restablecer la variable
        }
    }
}
