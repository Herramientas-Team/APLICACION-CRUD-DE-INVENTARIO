﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Datos;
using System.Data.SqlClient;

namespace Negocios
{
    public class conProducto
    {
        public modProducto producto;

        public conProducto()
        {
            producto = new modProducto();
        }

        public bool ObtenerProductoPorId(string id_producto)
        {
            return producto.ObtenerProductoPorId(id_producto);
        }

        public bool ActualizarProducto(modProducto producto)
        {
            return producto.ActualizarProducto(producto);
        }

        public bool EliminarProducto(string id_producto)
        {
            return producto.EliminarProducto(id_producto);
        }

        public bool AgregarProducto(modProducto producto)
        {
            return producto.AgregarProducto(producto);
        }
    }
}
