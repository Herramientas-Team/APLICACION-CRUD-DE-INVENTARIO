﻿namespace Presentacion
{
    partial class Inicio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Facturas = new Button();
            Clientes = new Button();
            Productos = new Button();
            Categorias = new Button();
            panelMenuLateral = new Panel();
            panelSubMenuCategorias = new Panel();
            btnNuevaCategoria = new Button();
            btnVerCategorias = new Button();
            btnMenuCategorias = new Button();
            panelSubMenuProductos = new Panel();
            btnNuevoProducto = new Button();
            btnVerProductos = new Button();
            btnMenuProductos = new Button();
            btnIniciarSesion = new Button();
            btnCerrarSesion = new Button();
            panelSubMenuFacturas = new Panel();
            btnNuevaFactura = new Button();
            btnHistorialFacturas = new Button();
            btnMenuFacturas = new Button();
            panelSubMenuClientes = new Panel();
            btnNuevoCliente = new Button();
            btnVerClientes = new Button();
            btnMenuClientes = new Button();
            panelLogo = new Panel();
            panelChildForm = new Panel();
            pictureBox1 = new PictureBox();
            panelMenuLateral.SuspendLayout();
            panelSubMenuCategorias.SuspendLayout();
            panelSubMenuProductos.SuspendLayout();
            panelSubMenuFacturas.SuspendLayout();
            panelSubMenuClientes.SuspendLayout();
            panelChildForm.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // Facturas
            // 
            Facturas.Location = new Point(0, 0);
            Facturas.Name = "Facturas";
            Facturas.Size = new Size(75, 23);
            Facturas.TabIndex = 0;
            // 
            // Clientes
            // 
            Clientes.Location = new Point(0, 0);
            Clientes.Name = "Clientes";
            Clientes.Size = new Size(75, 23);
            Clientes.TabIndex = 0;
            // 
            // Productos
            // 
            Productos.Location = new Point(0, 0);
            Productos.Name = "Productos";
            Productos.Size = new Size(75, 23);
            Productos.TabIndex = 0;
            // 
            // Categorias
            // 
            Categorias.Location = new Point(0, 0);
            Categorias.Name = "Categorias";
            Categorias.Size = new Size(75, 23);
            Categorias.TabIndex = 0;
            // 
            // panelMenuLateral
            // 
            panelMenuLateral.AutoScroll = true;
            panelMenuLateral.BackColor = Color.FromArgb(25, 26, 24);
            panelMenuLateral.Controls.Add(panelSubMenuCategorias);
            panelMenuLateral.Controls.Add(btnMenuCategorias);
            panelMenuLateral.Controls.Add(panelSubMenuProductos);
            panelMenuLateral.Controls.Add(btnMenuProductos);
            panelMenuLateral.Controls.Add(btnIniciarSesion);
            panelMenuLateral.Controls.Add(btnCerrarSesion);
            panelMenuLateral.Controls.Add(panelSubMenuFacturas);
            panelMenuLateral.Controls.Add(btnMenuFacturas);
            panelMenuLateral.Controls.Add(panelSubMenuClientes);
            panelMenuLateral.Controls.Add(btnMenuClientes);
            panelMenuLateral.Controls.Add(panelLogo);
            panelMenuLateral.Dock = DockStyle.Left;
            panelMenuLateral.Location = new Point(0, 0);
            panelMenuLateral.Name = "panelMenuLateral";
            panelMenuLateral.Size = new Size(250, 561);
            panelMenuLateral.TabIndex = 0;
            // 
            // panelSubMenuCategorias
            // 
            panelSubMenuCategorias.BackColor = Color.FromArgb(35, 36, 34);
            panelSubMenuCategorias.Controls.Add(btnNuevaCategoria);
            panelSubMenuCategorias.Controls.Add(btnVerCategorias);
            panelSubMenuCategorias.Dock = DockStyle.Top;
            panelSubMenuCategorias.Location = new Point(0, 680);
            panelSubMenuCategorias.Name = "panelSubMenuCategorias";
            panelSubMenuCategorias.Size = new Size(233, 86);
            panelSubMenuCategorias.TabIndex = 10;
            // 
            // btnNuevaCategoria
            // 
            btnNuevaCategoria.Dock = DockStyle.Top;
            btnNuevaCategoria.FlatAppearance.BorderSize = 0;
            btnNuevaCategoria.FlatAppearance.MouseDownBackColor = Color.FromArgb(11, 114, 110);
            btnNuevaCategoria.FlatAppearance.MouseOverBackColor = Color.FromArgb(11, 114, 110);
            btnNuevaCategoria.FlatStyle = FlatStyle.Flat;
            btnNuevaCategoria.ForeColor = SystemColors.Window;
            btnNuevaCategoria.Location = new Point(0, 40);
            btnNuevaCategoria.Name = "btnNuevaCategoria";
            btnNuevaCategoria.Padding = new Padding(35, 0, 0, 0);
            btnNuevaCategoria.Size = new Size(233, 40);
            btnNuevaCategoria.TabIndex = 3;
            btnNuevaCategoria.Text = "Nueva Categoría";
            btnNuevaCategoria.TextAlign = ContentAlignment.MiddleLeft;
            btnNuevaCategoria.UseVisualStyleBackColor = true;
            // 
            // btnVerCategorias
            // 
            btnVerCategorias.Dock = DockStyle.Top;
            btnVerCategorias.FlatAppearance.BorderSize = 0;
            btnVerCategorias.FlatAppearance.MouseDownBackColor = Color.FromArgb(11, 114, 110);
            btnVerCategorias.FlatAppearance.MouseOverBackColor = Color.FromArgb(11, 114, 110);
            btnVerCategorias.FlatStyle = FlatStyle.Flat;
            btnVerCategorias.ForeColor = SystemColors.Window;
            btnVerCategorias.Location = new Point(0, 0);
            btnVerCategorias.Name = "btnVerCategorias";
            btnVerCategorias.Padding = new Padding(35, 0, 0, 0);
            btnVerCategorias.Size = new Size(233, 40);
            btnVerCategorias.TabIndex = 2;
            btnVerCategorias.Text = "Ver Categorías";
            btnVerCategorias.TextAlign = ContentAlignment.MiddleLeft;
            btnVerCategorias.UseVisualStyleBackColor = true;
            // 
            // btnMenuCategorias
            // 
            btnMenuCategorias.Dock = DockStyle.Top;
            btnMenuCategorias.FlatAppearance.BorderSize = 0;
            btnMenuCategorias.FlatStyle = FlatStyle.Flat;
            btnMenuCategorias.ForeColor = SystemColors.Window;
            btnMenuCategorias.Image = Properties.Resources.folder;
            btnMenuCategorias.ImageAlign = ContentAlignment.MiddleRight;
            btnMenuCategorias.Location = new Point(0, 614);
            btnMenuCategorias.Name = "btnMenuCategorias";
            btnMenuCategorias.Padding = new Padding(10, 0, 0, 0);
            btnMenuCategorias.Size = new Size(233, 66);
            btnMenuCategorias.TabIndex = 9;
            btnMenuCategorias.Text = "Categorías";
            btnMenuCategorias.TextAlign = ContentAlignment.MiddleLeft;
            btnMenuCategorias.UseVisualStyleBackColor = true;
            btnMenuCategorias.Click += btnMenuCategorias_Click;
            // 
            // panelSubMenuProductos
            // 
            panelSubMenuProductos.BackColor = Color.FromArgb(35, 36, 34);
            panelSubMenuProductos.Controls.Add(btnNuevoProducto);
            panelSubMenuProductos.Controls.Add(btnVerProductos);
            panelSubMenuProductos.Dock = DockStyle.Top;
            panelSubMenuProductos.Location = new Point(0, 528);
            panelSubMenuProductos.Name = "panelSubMenuProductos";
            panelSubMenuProductos.Size = new Size(233, 86);
            panelSubMenuProductos.TabIndex = 8;
            // 
            // btnNuevoProducto
            // 
            btnNuevoProducto.Dock = DockStyle.Top;
            btnNuevoProducto.FlatAppearance.BorderSize = 0;
            btnNuevoProducto.FlatAppearance.MouseDownBackColor = Color.FromArgb(11, 114, 110);
            btnNuevoProducto.FlatAppearance.MouseOverBackColor = Color.FromArgb(11, 114, 110);
            btnNuevoProducto.FlatStyle = FlatStyle.Flat;
            btnNuevoProducto.ForeColor = SystemColors.Window;
            btnNuevoProducto.Location = new Point(0, 40);
            btnNuevoProducto.Name = "btnNuevoProducto";
            btnNuevoProducto.Padding = new Padding(35, 0, 0, 0);
            btnNuevoProducto.Size = new Size(233, 40);
            btnNuevoProducto.TabIndex = 3;
            btnNuevoProducto.Text = "Nuevo Producto";
            btnNuevoProducto.TextAlign = ContentAlignment.MiddleLeft;
            btnNuevoProducto.UseVisualStyleBackColor = true;
            // 
            // btnVerProductos
            // 
            btnVerProductos.Dock = DockStyle.Top;
            btnVerProductos.FlatAppearance.BorderSize = 0;
            btnVerProductos.FlatAppearance.MouseDownBackColor = Color.FromArgb(11, 114, 110);
            btnVerProductos.FlatAppearance.MouseOverBackColor = Color.FromArgb(11, 114, 110);
            btnVerProductos.FlatStyle = FlatStyle.Flat;
            btnVerProductos.ForeColor = SystemColors.Window;
            btnVerProductos.Location = new Point(0, 0);
            btnVerProductos.Name = "btnVerProductos";
            btnVerProductos.Padding = new Padding(35, 0, 0, 0);
            btnVerProductos.Size = new Size(233, 40);
            btnVerProductos.TabIndex = 2;
            btnVerProductos.Text = "Ver Productos";
            btnVerProductos.TextAlign = ContentAlignment.MiddleLeft;
            btnVerProductos.UseVisualStyleBackColor = true;
            // 
            // btnMenuProductos
            // 
            btnMenuProductos.Dock = DockStyle.Top;
            btnMenuProductos.FlatAppearance.BorderSize = 0;
            btnMenuProductos.FlatStyle = FlatStyle.Flat;
            btnMenuProductos.ForeColor = SystemColors.Window;
            btnMenuProductos.Image = Properties.Resources.product;
            btnMenuProductos.ImageAlign = ContentAlignment.MiddleRight;
            btnMenuProductos.Location = new Point(0, 462);
            btnMenuProductos.Name = "btnMenuProductos";
            btnMenuProductos.Padding = new Padding(10, 0, 0, 0);
            btnMenuProductos.Size = new Size(233, 66);
            btnMenuProductos.TabIndex = 7;
            btnMenuProductos.Text = "Productos";
            btnMenuProductos.TextAlign = ContentAlignment.MiddleLeft;
            btnMenuProductos.UseVisualStyleBackColor = true;
            btnMenuProductos.Click += btnMenuProductos_Click;
            // 
            // btnIniciarSesion
            // 
            btnIniciarSesion.BackColor = Color.FromArgb(57, 213, 207);
            btnIniciarSesion.Dock = DockStyle.Bottom;
            btnIniciarSesion.FlatAppearance.BorderSize = 0;
            btnIniciarSesion.FlatStyle = FlatStyle.Flat;
            btnIniciarSesion.Location = new Point(0, 766);
            btnIniciarSesion.Name = "btnIniciarSesion";
            btnIniciarSesion.Size = new Size(233, 40);
            btnIniciarSesion.TabIndex = 6;
            btnIniciarSesion.Text = "Iniciar Sesión";
            btnIniciarSesion.UseVisualStyleBackColor = false;
            btnIniciarSesion.Click += btnIniciarSesion_Click;
            // 
            // btnCerrarSesion
            // 
            btnCerrarSesion.BackColor = Color.FromArgb(57, 213, 207);
            btnCerrarSesion.Dock = DockStyle.Bottom;
            btnCerrarSesion.FlatAppearance.BorderSize = 0;
            btnCerrarSesion.FlatStyle = FlatStyle.Flat;
            btnCerrarSesion.Location = new Point(0, 806);
            btnCerrarSesion.Name = "btnCerrarSesion";
            btnCerrarSesion.Size = new Size(233, 40);
            btnCerrarSesion.TabIndex = 5;
            btnCerrarSesion.Text = "Cerrar Sesión";
            btnCerrarSesion.UseVisualStyleBackColor = false;
            btnCerrarSesion.Click += btnCerrarSesion_Click;
            // 
            // panelSubMenuFacturas
            // 
            panelSubMenuFacturas.BackColor = Color.FromArgb(35, 36, 34);
            panelSubMenuFacturas.Controls.Add(btnNuevaFactura);
            panelSubMenuFacturas.Controls.Add(btnHistorialFacturas);
            panelSubMenuFacturas.Dock = DockStyle.Top;
            panelSubMenuFacturas.Location = new Point(0, 376);
            panelSubMenuFacturas.Name = "panelSubMenuFacturas";
            panelSubMenuFacturas.Size = new Size(233, 86);
            panelSubMenuFacturas.TabIndex = 4;
            // 
            // btnNuevaFactura
            // 
            btnNuevaFactura.Dock = DockStyle.Top;
            btnNuevaFactura.FlatAppearance.BorderSize = 0;
            btnNuevaFactura.FlatAppearance.MouseDownBackColor = Color.FromArgb(11, 114, 110);
            btnNuevaFactura.FlatAppearance.MouseOverBackColor = Color.FromArgb(11, 114, 110);
            btnNuevaFactura.FlatStyle = FlatStyle.Flat;
            btnNuevaFactura.ForeColor = SystemColors.Window;
            btnNuevaFactura.Location = new Point(0, 40);
            btnNuevaFactura.Name = "btnNuevaFactura";
            btnNuevaFactura.Padding = new Padding(35, 0, 0, 0);
            btnNuevaFactura.Size = new Size(233, 40);
            btnNuevaFactura.TabIndex = 3;
            btnNuevaFactura.Text = "Nueva Factura";
            btnNuevaFactura.TextAlign = ContentAlignment.MiddleLeft;
            btnNuevaFactura.UseVisualStyleBackColor = true;
            // 
            // btnHistorialFacturas
            // 
            btnHistorialFacturas.Dock = DockStyle.Top;
            btnHistorialFacturas.FlatAppearance.BorderSize = 0;
            btnHistorialFacturas.FlatAppearance.MouseDownBackColor = Color.FromArgb(11, 114, 110);
            btnHistorialFacturas.FlatAppearance.MouseOverBackColor = Color.FromArgb(11, 114, 110);
            btnHistorialFacturas.FlatStyle = FlatStyle.Flat;
            btnHistorialFacturas.ForeColor = SystemColors.Window;
            btnHistorialFacturas.Location = new Point(0, 0);
            btnHistorialFacturas.Name = "btnHistorialFacturas";
            btnHistorialFacturas.Padding = new Padding(35, 0, 0, 0);
            btnHistorialFacturas.Size = new Size(233, 40);
            btnHistorialFacturas.TabIndex = 2;
            btnHistorialFacturas.Text = "Historial de Facturas";
            btnHistorialFacturas.TextAlign = ContentAlignment.MiddleLeft;
            btnHistorialFacturas.UseVisualStyleBackColor = true;
            btnHistorialFacturas.Click += button7_Click;
            // 
            // btnMenuFacturas
            // 
            btnMenuFacturas.Dock = DockStyle.Top;
            btnMenuFacturas.FlatAppearance.BorderSize = 0;
            btnMenuFacturas.FlatStyle = FlatStyle.Flat;
            btnMenuFacturas.ForeColor = SystemColors.Window;
            btnMenuFacturas.Image = Properties.Resources.bill;
            btnMenuFacturas.ImageAlign = ContentAlignment.MiddleRight;
            btnMenuFacturas.Location = new Point(0, 310);
            btnMenuFacturas.Name = "btnMenuFacturas";
            btnMenuFacturas.Padding = new Padding(10, 0, 0, 0);
            btnMenuFacturas.Size = new Size(233, 66);
            btnMenuFacturas.TabIndex = 3;
            btnMenuFacturas.Text = "Facturas";
            btnMenuFacturas.TextAlign = ContentAlignment.MiddleLeft;
            btnMenuFacturas.UseVisualStyleBackColor = true;
            btnMenuFacturas.Click += btnMenuFacturas_Click;
            // 
            // panelSubMenuClientes
            // 
            panelSubMenuClientes.BackColor = Color.FromArgb(35, 36, 34);
            panelSubMenuClientes.Controls.Add(btnNuevoCliente);
            panelSubMenuClientes.Controls.Add(btnVerClientes);
            panelSubMenuClientes.Dock = DockStyle.Top;
            panelSubMenuClientes.Location = new Point(0, 225);
            panelSubMenuClientes.Name = "panelSubMenuClientes";
            panelSubMenuClientes.Size = new Size(233, 85);
            panelSubMenuClientes.TabIndex = 2;
            panelSubMenuClientes.Paint += panelSubMenuAdministrador_Paint;
            // 
            // btnNuevoCliente
            // 
            btnNuevoCliente.Dock = DockStyle.Top;
            btnNuevoCliente.FlatAppearance.BorderSize = 0;
            btnNuevoCliente.FlatAppearance.MouseDownBackColor = Color.FromArgb(11, 114, 110);
            btnNuevoCliente.FlatAppearance.MouseOverBackColor = Color.FromArgb(11, 114, 110);
            btnNuevoCliente.FlatStyle = FlatStyle.Flat;
            btnNuevoCliente.ForeColor = SystemColors.Window;
            btnNuevoCliente.Location = new Point(0, 40);
            btnNuevoCliente.Name = "btnNuevoCliente";
            btnNuevoCliente.Padding = new Padding(35, 0, 0, 0);
            btnNuevoCliente.Size = new Size(233, 40);
            btnNuevoCliente.TabIndex = 3;
            btnNuevoCliente.Text = "Nuevo Cliente";
            btnNuevoCliente.TextAlign = ContentAlignment.MiddleLeft;
            btnNuevoCliente.UseVisualStyleBackColor = true;
            btnNuevoCliente.Click += btnCajeros_Click;
            // 
            // btnVerClientes
            // 
            btnVerClientes.Dock = DockStyle.Top;
            btnVerClientes.FlatAppearance.BorderSize = 0;
            btnVerClientes.FlatAppearance.MouseDownBackColor = Color.FromArgb(11, 114, 110);
            btnVerClientes.FlatAppearance.MouseOverBackColor = Color.FromArgb(11, 114, 110);
            btnVerClientes.FlatStyle = FlatStyle.Flat;
            btnVerClientes.ForeColor = SystemColors.Window;
            btnVerClientes.Location = new Point(0, 0);
            btnVerClientes.Name = "btnVerClientes";
            btnVerClientes.Padding = new Padding(35, 0, 0, 0);
            btnVerClientes.Size = new Size(233, 40);
            btnVerClientes.TabIndex = 2;
            btnVerClientes.Text = "Ver Clientes";
            btnVerClientes.TextAlign = ContentAlignment.MiddleLeft;
            btnVerClientes.UseVisualStyleBackColor = true;
            // 
            // btnMenuClientes
            // 
            btnMenuClientes.Dock = DockStyle.Top;
            btnMenuClientes.FlatAppearance.BorderSize = 0;
            btnMenuClientes.FlatStyle = FlatStyle.Flat;
            btnMenuClientes.ForeColor = SystemColors.Window;
            btnMenuClientes.Image = Properties.Resources.group;
            btnMenuClientes.ImageAlign = ContentAlignment.MiddleRight;
            btnMenuClientes.Location = new Point(0, 159);
            btnMenuClientes.Name = "btnMenuClientes";
            btnMenuClientes.Padding = new Padding(10, 0, 0, 0);
            btnMenuClientes.Size = new Size(233, 66);
            btnMenuClientes.TabIndex = 1;
            btnMenuClientes.Text = "Clientes";
            btnMenuClientes.TextAlign = ContentAlignment.MiddleLeft;
            btnMenuClientes.UseVisualStyleBackColor = true;
            btnMenuClientes.Click += btnMenuClientes_Click;
            // 
            // panelLogo
            // 
            panelLogo.BackgroundImage = Properties.Resources.Banner_Inventario1;
            panelLogo.Dock = DockStyle.Top;
            panelLogo.Location = new Point(0, 0);
            panelLogo.Name = "panelLogo";
            panelLogo.Size = new Size(233, 159);
            panelLogo.TabIndex = 0;
            // 
            // panelChildForm
            // 
            panelChildForm.BackColor = Color.FromArgb(26, 28, 28);
            panelChildForm.Controls.Add(pictureBox1);
            panelChildForm.Dock = DockStyle.Fill;
            panelChildForm.Location = new Point(250, 0);
            panelChildForm.Name = "panelChildForm";
            panelChildForm.Size = new Size(684, 561);
            panelChildForm.TabIndex = 1;
            panelChildForm.Paint += panelChildForm_Paint;
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = AnchorStyles.None;
            pictureBox1.Image = Properties.Resources.Inventario_Tienda_Logo;
            pictureBox1.Location = new Point(181, 100);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(346, 346);
            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // Inicio
            // 
            AutoScaleDimensions = new SizeF(8F, 16F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(934, 561);
            Controls.Add(panelChildForm);
            Controls.Add(panelMenuLateral);
            Font = new Font("Verdana", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            MinimumSize = new Size(950, 600);
            Name = "Inicio";
            Text = "Inicio";
            panelMenuLateral.ResumeLayout(false);
            panelSubMenuCategorias.ResumeLayout(false);
            panelSubMenuProductos.ResumeLayout(false);
            panelSubMenuFacturas.ResumeLayout(false);
            panelSubMenuClientes.ResumeLayout(false);
            panelChildForm.ResumeLayout(false);
            panelChildForm.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panelMenuLateral;
        private Panel panelSubMenuClientes;
        private Button btnMenuClientes;
        private Panel panelLogo;
        private Panel panelChildForm;
        private PictureBox pictureBox1;
        private Button btnNuevoCliente;
        private Button btnVerClientes;
        private Button btnIniciarSesion;
        private Button btnCerrarSesion;
        private Panel panelSubMenuFacturas;
        private Button btnHistorialFacturas;
        private Button btnMenuFacturas;
        private Button btnMenuProductos;
        private Button btnNuevaFactura;
        private Panel panelSubMenuCategorias;
        private Button btnNuevaCategoria;
        private Button btnVerCategorias;
        private Button btnMenuCategorias;
        private Panel panelSubMenuProductos;
        private Button btnNuevoProducto;
        private Button btnVerProductos;
    }
}