﻿namespace Presentacion
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBoxContraseña = new TextBox();
            label2 = new Label();
            label3 = new Label();
            button1 = new Button();
            textBoxNombreUsuario = new TextBox();
            label1 = new Label();
            labelError = new Label();
            SuspendLayout();
            // 
            // textBoxContraseña
            // 
            textBoxContraseña.Anchor = AnchorStyles.None;
            textBoxContraseña.Location = new Point(253, 298);
            textBoxContraseña.Name = "textBoxContraseña";
            textBoxContraseña.PasswordChar = '*';
            textBoxContraseña.Size = new Size(180, 23);
            textBoxContraseña.TabIndex = 1;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.Window;
            label2.Location = new Point(294, 268);
            label2.Name = "label2";
            label2.Size = new Size(101, 18);
            label2.TabIndex = 3;
            label2.Text = "Contraseña";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.Font = new Font("Impact", 24F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label3.ForeColor = SystemColors.Window;
            label3.Location = new Point(233, 104);
            label3.Name = "label3";
            label3.Size = new Size(223, 39);
            label3.TabIndex = 4;
            label3.Text = "Inicio de sesión";
            // 
            // button1
            // 
            button1.Anchor = AnchorStyles.None;
            button1.Location = new Point(302, 351);
            button1.Name = "button1";
            button1.Size = new Size(88, 30);
            button1.TabIndex = 5;
            button1.Text = "Entrar";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // textBoxNombreUsuario
            // 
            textBoxNombreUsuario.Anchor = AnchorStyles.None;
            textBoxNombreUsuario.Location = new Point(253, 214);
            textBoxNombreUsuario.Name = "textBoxNombreUsuario";
            textBoxNombreUsuario.PasswordChar = '*';
            textBoxNombreUsuario.Size = new Size(180, 23);
            textBoxNombreUsuario.TabIndex = 6;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.Window;
            label1.Location = new Point(306, 181);
            label1.Name = "label1";
            label1.Size = new Size(71, 18);
            label1.TabIndex = 7;
            label1.Text = "Nombre";
            // 
            // labelError
            // 
            labelError.AutoSize = true;
            labelError.ForeColor = SystemColors.Window;
            labelError.Location = new Point(318, 427);
            labelError.Name = "labelError";
            labelError.Size = new Size(45, 16);
            labelError.TabIndex = 8;
            labelError.Text = "label4";
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(8F, 16F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(26, 28, 28);
            ClientSize = new Size(684, 561);
            Controls.Add(labelError);
            Controls.Add(label1);
            Controls.Add(textBoxNombreUsuario);
            Controls.Add(button1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(textBoxContraseña);
            Font = new Font("Verdana", 9.75F);
            Name = "Login";
            Text = "Login";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox textBoxContraseña;
        private Label label2;
        private Label label3;
        private Button button1;
        private TextBox textBoxNombreUsuario;
        private Label label1;
        private Label labelError;
    }
}