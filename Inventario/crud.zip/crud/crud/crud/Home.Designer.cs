﻿namespace Presentacion
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            Panelopciones = new Panel();
            Btn_CajerosIngresar = new Button();
            Btn_AdminIngresar = new Button();
            pictureBox1 = new PictureBox();
            panelcontenedor = new Panel();
            Panelopciones.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // Panelopciones
            // 
            Panelopciones.BackColor = Color.Gray;
            Panelopciones.Controls.Add(Btn_CajerosIngresar);
            Panelopciones.Controls.Add(Btn_AdminIngresar);
            Panelopciones.Controls.Add(pictureBox1);
            Panelopciones.Dock = DockStyle.Left;
            Panelopciones.Location = new Point(0, 0);
            Panelopciones.Name = "Panelopciones";
            Panelopciones.Size = new Size(180, 516);
            Panelopciones.TabIndex = 2;
            // 
            // Btn_CajerosIngresar
            // 
            Btn_CajerosIngresar.BackColor = Color.FromArgb(26, 32, 40);
            Btn_CajerosIngresar.FlatAppearance.BorderSize = 0;
            Btn_CajerosIngresar.FlatAppearance.MouseOverBackColor = Color.FromArgb(49, 66, 86);
            Btn_CajerosIngresar.FlatStyle = FlatStyle.Flat;
            Btn_CajerosIngresar.Font = new Font("Corbel", 11.25F);
            Btn_CajerosIngresar.ForeColor = Color.White;
            Btn_CajerosIngresar.Image = (Image)resources.GetObject("Btn_CajerosIngresar.Image");
            Btn_CajerosIngresar.ImageAlign = ContentAlignment.MiddleRight;
            Btn_CajerosIngresar.Location = new Point(12, 258);
            Btn_CajerosIngresar.Name = "Btn_CajerosIngresar";
            Btn_CajerosIngresar.Size = new Size(162, 37);
            Btn_CajerosIngresar.TabIndex = 2;
            Btn_CajerosIngresar.Text = "Cajero";
            Btn_CajerosIngresar.TextAlign = ContentAlignment.MiddleLeft;
            Btn_CajerosIngresar.UseVisualStyleBackColor = false;
            // 
            // Btn_AdminIngresar
            // 
            Btn_AdminIngresar.BackColor = Color.FromArgb(26, 32, 40);
            Btn_AdminIngresar.FlatAppearance.BorderSize = 0;
            Btn_AdminIngresar.FlatAppearance.MouseOverBackColor = Color.FromArgb(49, 66, 86);
            Btn_AdminIngresar.FlatStyle = FlatStyle.Flat;
            Btn_AdminIngresar.Font = new Font("Corbel", 11.25F);
            Btn_AdminIngresar.ForeColor = Color.White;
            Btn_AdminIngresar.Image = (Image)resources.GetObject("Btn_AdminIngresar.Image");
            Btn_AdminIngresar.ImageAlign = ContentAlignment.MiddleRight;
            Btn_AdminIngresar.Location = new Point(12, 215);
            Btn_AdminIngresar.Name = "Btn_AdminIngresar";
            Btn_AdminIngresar.Size = new Size(162, 37);
            Btn_AdminIngresar.TabIndex = 1;
            Btn_AdminIngresar.Text = "Admin";
            Btn_AdminIngresar.TextAlign = ContentAlignment.MiddleLeft;
            Btn_AdminIngresar.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(6, 21);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(168, 165);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // panelcontenedor
            // 
            panelcontenedor.BackColor = Color.FromArgb(49, 66, 86);
            panelcontenedor.Dock = DockStyle.Fill;
            panelcontenedor.Location = new Point(180, 0);
            panelcontenedor.Name = "panelcontenedor";
            panelcontenedor.Size = new Size(804, 516);
            panelcontenedor.TabIndex = 3;
            // 
            // Home
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(984, 516);
            Controls.Add(panelcontenedor);
            Controls.Add(Panelopciones);
            MaximizeBox = false;
            MdiChildrenMinimizedAnchorBottom = false;
            MinimizeBox = false;
            Name = "Home";
            Text = "Form2";
            Panelopciones.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel Panelopciones;
        private Button Btn_CajerosIngresar;
        private Button Btn_AdminIngresar;
        private PictureBox pictureBox1;
        private Panel panelcontenedor;
    }
}