﻿namespace Presentacion
{
    partial class CajeroLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            botonCancelar = new Button();
            botonIngresarUSER = new Button();
            textContraseñaUSER = new TextBox();
            textUSER = new TextBox();
            label5 = new Label();
            label4 = new Label();
            SuspendLayout();
            // 
            // botonCancelar
            // 
            botonCancelar.BackColor = Color.Transparent;
            botonCancelar.Font = new Font("Stencil", 9.75F);
            botonCancelar.Location = new Point(308, 305);
            botonCancelar.Name = "botonCancelar";
            botonCancelar.Size = new Size(184, 40);
            botonCancelar.TabIndex = 21;
            botonCancelar.UseVisualStyleBackColor = false;
            // 
            // botonIngresarUSER
            // 
            botonIngresarUSER.BackColor = Color.Transparent;
            botonIngresarUSER.Font = new Font("Stencil", 9.75F);
            botonIngresarUSER.Location = new Point(308, 259);
            botonIngresarUSER.Name = "botonIngresarUSER";
            botonIngresarUSER.Size = new Size(184, 40);
            botonIngresarUSER.TabIndex = 20;
            botonIngresarUSER.UseVisualStyleBackColor = false;
            // 
            // textContraseñaUSER
            // 
            textContraseñaUSER.Location = new Point(347, 188);
            textContraseñaUSER.Name = "textContraseñaUSER";
            textContraseñaUSER.Size = new Size(109, 23);
            textContraseñaUSER.TabIndex = 19;
            // 
            // textUSER
            // 
            textUSER.Location = new Point(347, 123);
            textUSER.Name = "textUSER";
            textUSER.Size = new Size(109, 23);
            textUSER.TabIndex = 18;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(369, 170);
            label5.Name = "label5";
            label5.Size = new Size(67, 15);
            label5.TabIndex = 17;
            label5.Text = "Contraseña";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(378, 105);
            label4.Name = "label4";
            label4.Size = new Size(47, 15);
            label4.TabIndex = 16;
            label4.Text = "Usuario";
            // 
            // CajeroLogin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(botonCancelar);
            Controls.Add(botonIngresarUSER);
            Controls.Add(textContraseñaUSER);
            Controls.Add(textUSER);
            Controls.Add(label5);
            Controls.Add(label4);
            Name = "CajeroLogin";
            Text = "Cajero • Login";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button botonCancelar;
        private Button botonIngresarUSER;
        private TextBox textContraseñaUSER;
        private TextBox textUSER;
        private Label label5;
        private Label label4;
    }
}